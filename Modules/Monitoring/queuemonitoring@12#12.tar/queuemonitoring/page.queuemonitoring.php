<h2>خلاصه وضعیت صف‌ها</h2>

<link rel="stylesheet" href="modules/queuemonitoring/style/style.css" />

<table id="queuemonitoring" class="header_table">
	<thead>
		<tr>
			<td style="width: 7%">
				<label> <span class="icon icon-status s18"></span> صف </label>
			</td>
			<td style="width: 70%">
				<label> <span class="icon icon-user3 s18"></span> اپراتورها </label>
			</td>
			<td style="width: 23%">
				<label> <span class="icon icon-phone4 s18"></span> تماس‌ها </label>
			</td>
		</tr>
	</thead>
	<tbody>
	
	</tbody>

</table>


<script src="modules/queuemonitoring/javascript/script.js"></script>