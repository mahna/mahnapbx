<?php
	function nai_queuemonitoring_getlist_forper(){
		$ret = array();
		$i = 0;
		if( function_exists('nai_queues_getqueues') ) {
			$ques = nai_queues_getqueues();
			foreach($ques as $que) {
				$ret[$i]['id'] = $que['extension'];
				$ret[$i]['value'] = "$que[extension]";
				$ret[$i++]['title'] = "صف : $que[extension]";
			}
		}
		return $ret;
	}
	
	
	
	if( getor( $_GET['nai_module'] ) == 'queuemonitoring' && getor( $_GET['ajax'] ) == 'true' ){
		ob_clean();
		ob_clean();
		switch( getor( $_POST['request'] ) ){
			case 'logout':
				$agent = getor( $_POST['agent'] );
				$queue = getor( $_POST['queue'] );
				
				$cmd = "/usr/bin/sudo /usr/sbin/pbxcmd agentlogout $agent $queue";
				$check = shell_exec($cmd);
				$check_text = print_r($check,true)!=''?print_r($check,true):'پاسخی از سرور دریافت نشد!';
				echo $check_text; // to check_text
				
				break;
			
		}
		exit;
		
	}

?>