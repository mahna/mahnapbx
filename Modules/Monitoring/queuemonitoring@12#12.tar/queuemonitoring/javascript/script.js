var flags = [];
var qList;

nodeSocket.emit('nodeqami.requestJoin', userid );
nodeSocket.on('nodeqami.connected', function(){});

nodeSocket.emit('nodeqami.queue_monitoring', true );

nodeSocket.on('nodeqami.queues_call', function(data) {
	queuesCall( data);
});

nodeSocket.on('nodeqami.queuesList', function (queuez) {
	filterReceivedData( queuez, function(queues){
		var i,j,qId,qStrategy,qOperators;
		var cont = $('#queuemonitoring > tbody');
		cont.html('');
		for( i = 0; i < queues.length; i++ ){
			qId = "queue-" + queues[i].number;
			qStrategy = queues[i].strategy;
			qCont = $("<tr>").addClass("queue").attr("id" , qId ).appendTo( cont );
			$("<td>").addClass("title").html( queues[i].number ).attr('title', qStrategy).appendTo( qCont );
			qOperators = $("<td>").addClass("operators").appendTo( qCont );
			$("<td>").addClass("calls").appendTo( qCont );
			for( j = 0; j < queues[i].members.length; j++ ){
				$("<span>").on('click', removeMember ).attr("class",  "operator").attr('data-queue',queues[i].number).attr('data-agent',queues[i].members[j].number).attr("id", qId + '-' + queues[i].members[j].number ).html( queues[i].members[j].number ).appendTo( qOperators );
			}
		}

		var h = $('#page_cont').outerHeight(true)- 190;
		var eachRow = ( h / queues.length );
		if( eachRow > 70 )
			cont.find('tr').css('height', eachRow+'px');
	
	});
});




function queuesCall( data ){
	if( typeof flags[ data.uniqueid ] == "undefined" )
		flags[ data.uniqueid ] = {};

	flags[data.uniqueid].event = data.event;
	//console.log( flags[data.uniqueid].event );
	switch( data.event ){
		case "Join":
			flags[data.uniqueid].status = 'wait';
			flags[data.uniqueid].number = data.calleridnum;
			flags[data.uniqueid].queue = data.queue;
			flags[data.uniqueid].agent = '';
			flags[data.uniqueid].agentElem = $();
			flags[data.uniqueid].numberElem = $('<span>').addClass('call').attr('data-status', flags[data.uniqueid].status ).text( data.calleridnum );
			flags[data.uniqueid].queueElem = $('#queue-' + flags[data.uniqueid].queue + ' .calls');
			
			flags[data.uniqueid].numberElem.appendTo( flags[data.uniqueid].queueElem );
			break;
		case "AgentCalled":
			flags[data.uniqueid].status = 'ringing';
			flags[data.uniqueid].agent = (data.agentcalled.match(/\/(.*?)@/)).toString().match(/\d+/g)[0];
			flags[data.uniqueid].agentElem = $('#queue-'+flags[data.uniqueid].queue+'-'+flags[data.uniqueid].agent);
			
			flags[data.uniqueid].numberElem.attr('data-status', flags[data.uniqueid].status ).appendTo( flags[data.uniqueid].agentElem );
			break;
		case "AgentRingNoAnswer":
			flags[data.uniqueid].status = 'noanswer';
		
			flags[data.uniqueid].numberElem.attr('data-status', flags[data.uniqueid].status ).appendTo( flags[data.uniqueid].queueElem );
			break;
		case "AgentConnect":
			flags[data.uniqueid].status = 'talking';
			flags[data.uniqueid].agent = (data.channel.match(/\/(.*?)@/)).toString().match(/\d+/g)[0];
			flags[data.uniqueid].agentElem = $('#queue-'+flags[data.uniqueid].queue+'-'+flags[data.uniqueid].agent);
			
			flags[data.uniqueid].numberElem.attr('data-status', flags[data.uniqueid].status ).appendTo( flags[data.uniqueid].agentElem );
			break;
		case "AgentComplete":
		case "Hangup":
			flags[data.uniqueid].status = 'endcall';
			
			flags[data.uniqueid].numberElem.attr('data-status', flags[data.uniqueid].status ).fadeOut(function(){
				$(this).remove();
				flags[data.uniqueid] = {};
			});
			break;
	}
}

function filterReceivedData(arg, callback){
	var me = this;
	me.ret = 'not set yet';
	$.ajax({
		url: 'config.php?nai_module=nodeqami&ajax=true',
		type: 'POST',
		data: {
			'request': 'mylist',
			'list': JSON.stringify( arg )
		},
		success: function(response){
			callback( JSON.parse( response ) );
		}
	});
}






// new in 11

function removeMember(cb){
	cb = typeof cb == 'function'? cb: function(){};
	var agent = $(this).data('agent');
	var queue = $(this).data('queue');
	if( confirm('آیا از حذف '+agent+' از صف '+queue+' مطمئنید؟') ){
		$.ajax({
			url: 'config.php?nai_module=queuemonitoring&ajax=true',
			type: 'POST',
			data: {
				'request': 'logout',
				'agent': agent,
				'queue': queue
			},
			success: function(response){
				cb(response);
				alert( response );
			}
		});	
	}
}

