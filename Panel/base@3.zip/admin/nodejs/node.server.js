var http        = require('http').createServer().listen(843),
    io          = require('socket.io').listen(http),
    os          = require('os'),
    exec        = require('child_process').exec,
    async       = require('async'),
    mysql       = require('mysql'),
    AsteriskAmi = require('asterisk-ami'),
    ami         = new AsteriskAmi({ 
                                    host:       '127.0.0.1', 
                                    username:   'nodi', 
                                    password:   'modi' 
                                }),
    connection  = mysql.createConnection({
                                    host        : 'localhost',
                                    user        : 'root',
                                    password    : ''
                                }),
    globalVar   = [],
    respond     = {};

// Config Objects
connection.connect(function(err) {
    if (err) {
        console.error('error connecting: ' + err.stack);
        return;
    }
});

ami.connect();

globalVar['event']  = "QueueStatus";

io.configure(function(){
    
    io.set('log level', 1);
    
    io.set('transports', [ 'websocket' , 'flashsocket' ]);
    
});



// Listen for client
io.sockets.on("connection", function(socket){

    socket.on("callMonitoring", function(data){

        ami.send({ action: globalVar['event'] });
        
        ami.on('ami_data', function(data){
            
            ami_queueStatus( "callMonitoring_queueStatus", socket, data );
            
            if( data.event == "Join" && globalVar[data.uniqueid] == undefined ){

                globalVar[data.uniqueid] = data.uniqueid;

            }
            
            if( data.event == "Join" 
             || data.event == "Leave" 
             || data.event == "AgentCalled" 
             || data.event == "AgentConnect" 
             || data.event == "AgentComplete"
             || data.event == "Hangup" 
             || data.event == "AgentRingNoAnswer" ){
                
                if( data.uniqueid == globalVar[data.uniqueid] ){
                    
                    console.log( data.uniqueid );
                    console.log( globalVar[data.uniqueid] );
                    console.log( '...' );

                    console.log( JSON.stringify( data, null, 4) );
                    socket.emit( "queuesCall" , data );
                
                }

            }

            if( data.event == "QueueMemberAdded" || data.event == "QueueMemberRemoved" ){

                ami.send({ action: globalVar['event'] });

            }

        });
        
    });

    socket.on("dashboard", function(data){
                        
//        ami.on('ami_data', function(data){
//            
//            ami_queueStatus( "dashboard_queueStatus", socket, data );
//
//        });
        
        // Memory first Initialize
        socket.emit( "memoryInit", os.totalmem() );
        
        // Disk first Initialize
        drives( function (err, drives) {

            drivesDetail( drives, function (err, data) {

                socket.emit( "diskInit", data );

            });

        });

        // Interval for Memory and CPU
        setInterval(function(){

            memoryUsage = {
                "totalmem"  : os.totalmem(),
                "freemem"   : os.freemem()
            }

            executeCmd("top -bn1 | grep Cpu | cut -d',' -f4 | cut -d'%' -f1",function (err, data){
                socket.emit( "cpu", 100 - parseInt(data) );
            });

            socket.emit( "memory", memoryUsage );
            //io.sockets.emit( "cpu", getRandomInt(1, 100) );

        },1000 * 5);
        
        // Interval for Disk Infomation
        setInterval(function(){

            drives( function (err, drives) {

                drivesDetail( drives, function (err, data) {

                    socket.emit( "disk", data );

                });

            });

        },1000 * 60 * 60 * 5 );
        
        // Interval for AMI
        setInterval(function(){
            
            db_queueStatus( "dashboard_queueStatus", socket );
            
//            ami.send({ action: globalVar['event'] });

        },1000 * 2 );

    });

});

// Retrieve disks list.
function drives(callback) {
    
    executeCmd('df | awk \'{print $1}\'',
               
        function (err, stdout, stderr) {
            if (err) return callback(err);

            var drives = stdout.split('\n');

            drives.splice(0, 1);

            var index = drives.indexOf("tmpfs");
            drives.splice(index, 1);

            callback(null, drives);
        }
    );
};

// Retrieve space information about one drive.
function driveDetail(drive, callback) {
    detail(drive, callback);
};

// Retrieve space information about each drives.
function drivesDetail(drives, callback) {
    var drivesDetail = [];

    async.eachSeries(
        drives,
        function (drive, cb) {
            detail(
                drive,
                function (err, detail) {
                    if (err) return cb(err);
                    drivesDetail.push(detail);
                    cb();
                }
            );
        },
        function (err) {
            if (err) return callback(err);
            callback(null, drivesDetail);
        }
    );
};

// Retrieve space information about one drive.
function detail(drive, callback) {
    async.series(
        {
            used: function (callback) {
                executeCmd('df | grep ' + drive + ' | awk \'{print $3}\'', callback);
            },
            available: function (callback) {
                executeCmd('df | grep ' + drive + ' | awk \'{print $4}\'', callback);
            },
            mount: function (callback) {
                executeCmd('df | grep ' + drive + ' | awk \'{print $6}\'', callback);
            }
        },
        function (err, results) {
            if (err) return callback(err);

            results.used        = parseInt( results.used );
            results.available   = parseInt( results.available );
            results.total       = results.used + results.available;
            results.drive       = drive;

            callback(null, results);
        }
    );
}

// Execute a command.
function executeCmd(command, callback) {
    var child = exec(
        command,
        function (err, stdout, stderr) {
            if (err) return callback(err);
            callback(null, stdout.trim() );
        }
    );
}

// Get Random Number
function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function db_queueStatus( eventName, socket ){
    
    // Database transactions
    var query = "SELECT * FROM ( SELECT a.extension, MAX(b.id) maxId FROM asterisk.queues_config AS a JOIN asteriskcdrdb.queue_statistics AS b ON a.extension = b.queue GROUP BY a.extension ) AS T1 JOIN asteriskcdrdb.queue_statistics AS T2 ON T1.extension = T2.queue AND T1.maxId = T2.id";

    var queueArray = {};

    connection.query( query, function(err, queues){

        if(err) throw err;

        for ( var index in queues) {
            queueArray[ queues[index].extension ] = queues[index];
        }

        socket.emit( eventName, queueArray );

    });

/*var queues_query = "SELECT extension FROM asterisk.queues_config";

connection.query( queues_query, function(err, queues){
    
    if(err) throw err;

    setInterval(function(){
            
        for ( var index in queues) {

            var queue = queues[index].extension,
                query = "SELECT * FROM asteriskcdrdb.queue_statistics WHERE queue=" + queue + " ORDER BY call_date DESC LIMIT 1";

            connection.query( query, function(err, queuesDetails){

                if(err) throw err;

                console.log( JSON.stringify( queuesDetails, null, 5 ) );

            });

        }

    }, 1000 );

});*/

}
// ami_queueStatus
function ami_queueStatus( eventName, socket, data ){
    
    if( globalVar[data.actionid] == undefined ){

        globalVar[data.actionid] = data.actionid;

        respond = {},
        queues  = {};

    }

    if( globalVar[data.actionid] == data.actionid ){

        if( data.event == "QueueMember" || data.event == "QueueParams" || data.event == "QueueEntry" ){

            if( globalVar[data.queue] == undefined ){

                globalVar[data.queue] = data.queue;
                queueId = globalVar[data.queue];

            }else{

                queueId = globalVar[data.queue];

            }

            if( data.event == "QueueParams" ){

                respond[ queueId ] = {};

                respond[ queueId ]['QueueParams'] = data;

            }else if( data.event == "QueueEntry" && queueId == data.queue ){

                if( respond[ queueId ]['QueueEntry'] == undefined ){
                    respond[ queueId ]['QueueEntry'] = {};
                }

                respond[ queueId ]['QueueEntry'][data.position] = data;

            }else if( data.event == "QueueMember" && queueId == data.queue ){

                if( respond[ queueId ]['QueueMember'] == undefined ){
                    respond[ queueId ]['QueueMember'] = {};
                }

                respond[ queueId ]['QueueMember'][data.name] = data;
            }

        }

        if( !(data.event == undefined) ){

            if( data.event == globalVar['event'] + "Complete" ){

                console.log( JSON.stringify( respond, null, 4) );
                socket.emit( eventName, respond );

            }

        }

    }

}

