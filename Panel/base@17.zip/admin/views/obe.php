<?php
$html = '';
$html .= heading('خوش آمدید!', 3) . '<hr/>';
//$html .= '<div id="login_form">';
$html .= form_open($_SERVER['REQUEST_URI'], 'id="loginform"');

$html .= br(2);
$html .= heading(_('تنظیمات کاربر ادمین:'), 1) . '<hr/>';
//$html .= _('Please provide the core credentials that will be used to '
//        . 'administer your system');
$html .= br(1);
$table = new CI_Table;
if ($errors) {
	$html .= '<span class="obe_error">';
	$html .= _('Please correct the following errors:');
	$html .= ul($errors);
	$html .= '</span>';
}
//username
$label = fpbx_label(('نام کاربری:'), _('Admin user name'));
$data = array(
			'name' => 'username',
			'value'	=> $username,
			'required' => '',
			'placeholder' => _('username')
		);
$table->add_row($label, form_input($data));

//password
$label = fpbx_label(('رمز عبور'), _('Admin password'));
$data = array(
			'name' => 'password',
			'type' => 'password',
			'value'	=> $password,
			'required' => '',
			'placeholder' => _('password')
        );

$table->add_row($label, form_input($data));

//confirm password
$label = fpbx_label(('تکرار رمز عبور'));
$data = array(
			'name' => 'confirm_password',
			'value'	=> $confirm_password,
			'type' => 'password',
			'required' => '',
			'placeholder' => _('password')
        );

$table->add_row($label, form_input($data));

//email address
$label =  '';//fpbx_label(('ایمیل'));
$data = array(
			'name' 	=> 'email_address',
			'value'	=> $email_address,
			'type'	=> 'hidden',
			'placeholder' => _('email address')
        );

$table->add_row($label, form_input($data));

//Confirm email address
$label = '';//fpbx_label(('تکرار ایمیل'));
$data = array(
			'name' => 'confirm_email',
			'value'	=> $confirm_email,
			'type'	=> 'hidden',
			'placeholder' => _('confirm email')
        );

$table->add_row($label, form_input($data));

$html .= $table->generate();
$html .= br(2);
$html .= form_hidden('action', 'setup_admin');
$html .= form_submit('submit', ('ایجاد کاربر ادمین !'));
$html .= form_close();

/*$html .= '<script type="text/javascript">';
$html .= '$(document).ready(function(){
		$("#key").click(function(){
			dest = "ssh://" + window.location.hostname + " \"/usr/sbin/amportal a u ' . session_id() . '\"";
			console.log(dest)
			window.open(dest).close(); setTimeout(\'window.location.reload()\', 3000);
		});
})';
$html .= '</script>';*/



$html .= '	
<script type="text/javascript">
	$(document).ready(function(){
		$("#nai_content table").addClass("nai_table").addClass("conf_table");
	});
</script>
';


echo tag('div','id=nai_content class="rtl"',$html);

?>
