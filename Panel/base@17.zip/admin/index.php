<?php
header("Location: config.php");
?>
