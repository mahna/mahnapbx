var naiJax = new (function(){
	var self = this;
	
	
	
	self.call = function( action, parameters, callback ){
		var url = [];
		var queryString = 'config.php?';
		
		url.push( $.param({
			'naijax': true
		}));
		if( action.indexOf('::') !== -1 ){ // it is class
			var class_function = action.split('::');
			url.push( $.param({
				'class': class_function[0],
				'method': class_function[1]
			}));
		}
		else if( action.indexOf('->') !== -1 ){ // it is object
			var object_function = action.split('->');
			url.push( $.param({
				'object': object_function[0],
				'method': object_function[1]
			}));
		}
		else{ // it is just function
			url.push( $.param({
				'function': action
			}));
		}
		if( typeof parameters != 'undefined' ){
			url.push( $.param({
				'parameters': parameters
			}));
		}
		
		
		var sp = '';
		for( var i in url ){
			if( typeof url[i] != 'string' ) continue;
			queryString+= sp+ url[i];
			sp = '&';
		}
		
		
		$.getJSON( queryString, callback );
		return queryString;
	}

})();