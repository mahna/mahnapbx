function naiCountdown(elem,secs,callback){
	
	var me = this;
	
	me.$element = $(elem);
	me.totalTime = secs * 10;
	me.displayTime = function(){
		var totalSec = parseInt( (me.totalTime) / 10 );
		
		var hours = parseInt( totalSec / 3600 ) % 24;
		var minutes = parseInt( totalSec / 60 ) % 60;
		var seconds = totalSec % 60;

		var result = (hours < 10 ? "0" + hours : hours) + ":" + (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds  < 10 ? "0" + seconds : seconds);


		return result;
	}
	me.showTime = function(){
		me.$element.html( me.displayTime() );
	}
	
	me._timer = '';
	
	me.plusplus = function(){
		if( me.totalTime-1 <= 0 ){
			me.pause();
			callback();
			return false;
		}
		me.totalTime--;
		me.showTime();
		return true;
		
	}
	
	me.init = function(){
		me.showTime();
	}
	
	me.play = function(){
		if( me._timer ) return false;
		me.totalTime = Math.floor(me.totalTime / 10) * 10;
		
		me._timer = setInterval( me.plusplus, 100 );
		me.$element.addClass('play').removeClass('pause');
	}
	me.pause = function(){
		if( !me._timer ) return false;
		
		me.totalTime = Math.floor(me.totalTime / 10) * 10;
		
		clearInterval( me._timer );
		me._timer = null;
		me.$element.addClass('pause').removeClass('play');
	}
	
	me.init();
}
