<?php /* $Id: page.modules.php 15432 2013-03-29 17:53:39Z p_lindheimer $ */

/** Controls if online module and install/uninstall options are available.
 * This is meant for when using external packaging systems (eg, deb or rpm) to manage
 * modules. Package maintainers should set AMPEXTERNPACKAGES to true in /etc/amportal.conf.
 * Optionally, the other way is to remove the below lines, and instead just define 
 * EXTERNAL_PACKAGE_MANAGEMENT as 1. This prevents changing the setting from amportal.conf.
 */
if (!isset($amp_conf['AMPEXTERNPACKAGES']) || ($amp_conf['AMPEXTERNPACKAGES'] != 'true')) {
	define('EXTERNAL_PACKAGE_MANAGEMENT', 0);
} else {
	define('EXTERNAL_PACKAGE_MANAGEMENT', 1);
}

// Handle the ajax post back of an update online updates email array and status
//
if ($quietmode && !empty($_REQUEST['online_updates'])) {

	$online_updates = $_REQUEST['online_updates'];
	$update_email   = $_REQUEST['update_email'];
	$ci = new CI_Email();
	if (!$ci->valid_email($update_email) && $update_email) {
		$json_array['status'] = _("Invalid email address") . ' : ' . $update_email;
	} else {
		$cm =& cronmanager::create($db);
		$online_updates == 'yes' ?  $cm->enable_updates() : $cm->disable_updates();
		$cm->save_email($update_email);
		$json_array['status'] = true;
	}
	header("Content-type: application/json"); 
	echo json_encode($json_array);
	exit;
}

$extdisplay = isset($_REQUEST['extdisplay'])?$_REQUEST['extdisplay']:'';

global $active_repos;
$loc_domain = 'amp';
if (isset($_REQUEST['check_online'])) {
  $online = 1;
  $active_repos = $_REQUEST['active_repos'];
  module_set_active_repos($active_repos);
} else {
  $online = (isset($_REQUEST['online']) && $_REQUEST['online'] && !EXTERNAL_PACKAGE_MANAGEMENT) ? 1 : 0;
  $active_repos = module_get_active_repos();
}

// fix php errors from undefined variable. Not sure if we can just change the reference below to use
// online since it changes values so just setting to what we decided it is here.

$moduleaction = isset($_REQUEST['moduleaction'])?$_REQUEST['moduleaction']:false;
/*
	moduleaction is an array with the key as the module name, and possible values:
	
	downloadinstall - download and install (used when a module is not locally installed)
	upgrade - download and install (used when a module is locally installed)
	install - install/upgrade locally available module
	enable - enable local module
	disable - disable local module
	uninstall - uninstall local module
*/

$freepbx_version = get_framework_version();
$freepbx_version = $freepbx_version ? $freepbx_version : getversion();
$freepbx_help_url = "http://www.freepbx.org/freepbx-help-system?freepbx_version=".urlencode($freepbx_version);

if (!$quietmode) {
	$cm =& cronmanager::create($db);
	$online_updates = $cm->updates_enabled() ? 'yes' : 'no';
	$update_email   = $cm->get_email();

	if (!$cm->updates_enabled()) {
		$shield_class = 'updates_off';
	} else {
		$shield_class = $update_email ? 'updates_full' : 'updates_partial';
	}

	$update_blurb   = htmlspecialchars(_("FreePBX allows you to automatically check for updates online. The updates will NOT be automatically installed. The email address you provdie is NEVER transmitted off of your PBX. The email is used by your local PBX to send notificaitons of updates that are available as well as IMPORTANT Security Notifications. It is STRONGYLY advised that you keep this enabled and keep updated of these important notificaions to avoid costly security issues."));
	$ue = htmlspecialchars($update_email);
	?>
<div class="in">
	<script type="text/javascript">
	$(document).ready(function(){
		$('.repo_boxes').find('input[type=checkbox]').button();
		$('#show_auto_update').click(function() {
			autoupdate_box = $('#db_online').dialog({
				title: fpbx.msg.framework.updatenotifications,
				resizable: false,
				modal: true,
				position: ['center', 50],
				width: '400px',
				close: function (e) {
					//console.log('calling close');
					$('#update_email').val($('#update_email').attr('saved-value'));
				},
				open: function (e) {
					//console.log('calling open');
					$('#update_email').focus();
				},
				buttons: [ {
					text: fpbx.msg.framework.save,
					click: function() {
						if ($('#update_email')[0].validity.typeMismatch) {
							alert(fpbx.msg.framework.bademail + ' : ' + $('#update_email').focus().val());
							$('#update_email').focus();
						} else {
							online_updates = $('[name="online_updates"]:checked').val();
							update_email = $('#update_email').val();
							if (online_updates != 'yes') {
								if (!confirm(fpbx.msg.framework.noupdates)) {
									return false;
								}
							} else if (isEmpty(update_email)) {
								if (!confirm(fpbx.msg.framework.noupemail)) {
									return false;
								}
							}
    					$.ajax({
      					type: 'POST',
      					url: "<?php echo $_SERVER["PHP_SELF"]; ?>",
      					//data: "quietmode=1&skip_astman=1&display=modules&update_email=" + $('#update_email').val() + "&online_updates=" + $('[name="online_updates"]:checked').val(),
      					data: "quietmode=1&skip_astman=1&display=modules&update_email=" + update_email + "&online_updates=" + online_updates,
      					dataType: 'json',
      					success: function(data) {
									if (data.status == true) {
										$('#update_email').attr('saved-value', $('#update_email').val());
										if ($('[name="online_updates"]:checked').val() == 'no') {
											$('#shield_link').attr('class', 'updates_off');
										} else {
											$('#shield_link').attr('class', (isEmpty($('#update_email').val()) ? 'updates_partial' : 'updates_full'));
										}
										autoupdate_box.dialog("close")
									} else {
										alert(data.status)
										$('#update_email').focus();
									}
      					},
      					error: function(data) {
									alert(fpbx.msg.framework.invalid_response);
      					}
    					});
						}
					}
				}, {
					text: fpbx.msg.framework.cancel,
					click: function() {
						//console.log('pressed cancel button');
						$(this).dialog("close");
					}
				} ]
			});
		});
		$('.modulevul_tag').click(function(e) {
			e.preventDefault();
			$.each($(this).data('sec'), function(index, value) { 
				$('#security-' + value).dialog({
					title: fpbx.msg.framework.securityissue + ' ' + value,
					resizable: false,
					position: [50+20*index, 50+20*index],
					width: '450px',
					close: function (e) {
						//console.log('calling close');
					},
					open: function (e) {
						//console.log('calling open');
					},
					buttons: [ {
						text: fpbx.msg.framework.close,
						click: function() {
							//console.log('pressed cancel button');
							$(this).dialog("close");
						}
					} ]
				});
			});
		});
	})
	function toggleInfoPane(pane) {
		$('#'+pane).toggleClass('pane');
		/*
		var style = document.getElementById(pane).style;
		if (style.display == 'none' || style.display == '') {
			style.display = 'block';
		} else {
			style.display = 'none';
		}
		*/
	}
	function check_upgrade_all() {
		var re = /^moduleaction\[([a-z0-9_\-]+)\]$/;
		for(i=0; i<document.modulesGUI.elements.length; i++) {
			if (document.modulesGUI.elements[i].value == 'upgrade') {
				if (match = document.modulesGUI.elements[i].name.match(re)) {
					// check the box
					document.modulesGUI.elements[i].checked = true;
					// expand info pane
					document.getElementById('infopane_'+match[1]).style.display = 'block';
				}
			}
		}
	}
	function check_download_all() {
		var re = /^moduleaction\[([a-z0-9_\-]+)\]$/;
		for(i=0; i<document.modulesGUI.elements.length; i++) {
			if (document.modulesGUI.elements[i].value == 'downloadinstall') {
				if (match = document.modulesGUI.elements[i].name.match(re)) {
					// check the box
					document.modulesGUI.elements[i].checked = true;
					// expand info pane
					document.getElementById('infopane_'+match[1]).style.display = 'block';
				}
			}
		}
	}
	function showhide_upgrades() {
		var upgradesonly = document.getElementById('show_upgradable_only').checked;
		var module_re = /^module_([a-z0-9_-]+)$/;   // regex to match a module element id
		var cat_re = /^category_([a-zA-Z0-9_]+)$/; // regex to match a category element id
		var elements = document.getElementById('modulelist').getElementsByTagName('li');
		// loop through all modules, check if there is an upgrade_<module> radio box 
		for(i=0; i<elements.length; i++) {
			if (match = elements[i].id.match(module_re)) {
				if (!document.getElementById('upgrade_'+match[1])) {
					// not upgradable
					document.getElementById('module_'+match[1]).style.display = upgradesonly ? 'none' : 'block';
				}
			}
		}
		// hide category headings that don't have any visible modules
		var elements = document.getElementById('modulelist').getElementsByTagName('div');
		// loop through category items
		for(i=0; i<elements.length; i++) {
			if (elements[i].id.match(cat_re)) {
				var subelements = elements[i].getElementsByTagName('li');
				var display = false;
				for(j=0; j<subelements.length; j++) {
					// loop through children <li>'s, find names that are module element id's 
					if (subelements[j].id.match(module_re) && subelements[j].style.display != 'none') {
						// if at least one is visible, we're displaying this element
						display = true;
						break; // no need to go further
					}
				}
				document.getElementById(elements[i].id).style.display = display ? 'block' : 'none';
			}
		}
	}
	var box;
	function process_module_actions(actions) {
		urlStr = "config.php?type=<?php echo $type ?>&amp;display=modules&amp;extdisplay=process&amp;quietmode=1";
		for (var i in actions) {
			urlStr += "&amp;moduleaction["+i+"]="+actions[i];
		}
		 box = $('<div></div>')
			.html('<iframe id="iframestatus" frameBorder="0" src="'+urlStr+'"></iframe>')
			.dialog({
				title: 'وضعیت',
				resizable: false,
				modal: true,
				position: ['center', 50],
				width: '350px',
				close: function (e) {
					close_module_actions(true);
					$(e.target).dialog("destroy").remove();
				}
			});
	}
	function close_module_actions(goback) {
		box.dialog("destroy").remove();
		if (goback) {
      		location.href = 'config.php?display=modules&amp;type=<?php echo $type ?>&amp;online=<?php echo $online; ?>';
		}
	}
	</script>
	<?php

	echo "<h2>" . 'مدیریت ماژول ها' . "</h2><br>";

?>

<?php
  //TODO: decide if warnings of any sort need to be given, or just list of repos active?
} else {
	// $quietmode==true
	?>
	<html><head></head><body>
	<?php
}

$modules_local = module_getinfo(false,false,true);

if (!isset($modules)) {
	$modules = & $modules_local;
}

//--------------------------------------------------------------------------------------------------------
switch ($extdisplay) {  // process, confirm, or nothing
	case 'process':
		echo "<div id=\"moduleBoxContents\">";
		//nai_ echo "<h4>"._("Please wait while module actions are performed")."</h4>\n";
		echo "<div id=\"moduleprogress\"  style=\"font-family: tahoma; direction: rtl; font-size: 10pt;overflow: visible; height: auto;\">";

		// stop output buffering, and send output
		@ ob_flush();
		flush();
		foreach ($moduleaction as $modulename => $action) {	
			$didsomething = true; // set to false in default clause of switch() below..
			
			switch ($action) {
				case 'force_upgrade':
				case 'upgrade':
				case 'downloadinstall':
					if (!EXTERNAL_PACKAGE_MANAGEMENT) {
						echo sprintf(_('Downloading %s'), $modulename).' <span id="downloadprogress_'.$modulename.'"></span>';
						if (is_array($errors = module_download($modulename, false, 'download_progress'))) {
							echo '<span class="error">'.sprintf(_("Error(s) downloading %s"),$modulename).': ';
							echo '<ul><li>'.implode('</li><li>',$errors).'</li></ul>';
							echo '</span>';
						} else {
							if (is_array($errors = module_install($modulename))) {
								echo '<span class="error">'.sprintf(_("Error(s) installing %s"),$modulename).': ';
								echo '<ul><li>'.implode('</li><li>',$errors).'</li></ul>';
								echo '</span>';
							} else {
								echo '<span class="success">'.sprintf(_("%s installed successfully"),$modulename).'</span>';
							}
						}
					}
				break;
				case 'install':
					if (!EXTERNAL_PACKAGE_MANAGEMENT) {
						if (is_array($errors = module_install($modulename))) {
							echo '<span class="error">'.sprintf(_("Error(s) installing %s"),$modulename).': ';
							echo '<ul><li>'.implode('</li><li>',$errors).'</li></ul>';
							echo '</span>';
						} else {
							echo '<span class="success">'.sprintf(_("%s installed successfully"),$modulename).'</span>';
						}
					}
				break;
				case 'enable':
					if (is_array($errors = module_enable($modulename))) {
						echo '<span class="error">'.sprintf(_("Error(s) enabling %s"),$modulename).': ';
						echo '<ul><li>'.implode('</li><li>',$errors).'</li></ul>';
						echo '</span>';
					} else {
						echo '<span class="success">'.sprintf(_("%s enabled successfully"),$modulename).'</span>';
					}
				break;
				case 'disable':
					if (is_array($errors = module_disable($modulename))) {
						echo '<span class="error">'.sprintf(_("Error(s) disabling %s"),$modulename).': ';
						echo '<ul><li>'.implode('</li><li>',$errors).'</li></ul>';
						echo '</span>';
					} else {
						echo '<span class="success">'.sprintf(_("%s disabled successfully"),$modulename).'</span>';
					}
				break;
				case 'uninstall':
					if (!EXTERNAL_PACKAGE_MANAGEMENT) {
						if (is_array($errors = module_uninstall($modulename))) {
							echo '<span class="error">'.sprintf(_("Error(s) uninstalling %s"),$modulename).': ';
							echo '<ul><li>'.implode('</li><li>',$errors).'</li></ul>';
							echo '</span>';
						} else {
							echo '<span class="success">'.sprintf(_("%s uninstalled successfully"),$modulename).'</span>';
						}
					}
				break;
				default:
					// just so we don't send an <hr> and flush()
					$didsomething = false;
			}
			
			if ($didsomething) {
				echo " <br />";
				@ ob_flush();
				flush();
			}
		}
		echo "</div>";
		if ($quietmode) {
			//nai_  echo "\t<a style=\"font-family: tahoma\" href=\"#\" onclick=\"parent.close_module_actions(true);\" />"._("Return")."</a>";
		} else {
			//nai_ echo "\t<input type=\"button\" value=\""._("Return")."\" onclick=\"location.href = 'config.php?display=modules&amp;type=$type&amp;online=".$online."';\" />";
		echo "</div>";
		}
	break;
	case 'confirm':
		ksort($moduleaction);
		/* if updating language packs, make sure they are the last thing to be done so that
   		any modules currently being updated at the same time will be done so first and
	 		language pack updates for those modules will be included.
		*/
		if (isset($moduleaction['fw_langpacks'])) {
			$tmp = $moduleaction['fw_langpacks'];
			unset($moduleaction['fw_langpacks']);
			$moduleaction['fw_langpacks'] = $tmp;
			unset($tmp);
		}
		
		echo "<form name=\"modulesGUI\" action=\"config.php\" method=\"post\">";
		echo "<input type=\"hidden\" name=\"display\" value=\"".$display."\" />";
		echo "<input type=\"hidden\" name=\"type\" value=\"".$type."\" />";
		echo "<input type=\"hidden\" name=\"online\" value=\"".$online."\" />";
		echo "<input type=\"hidden\" name=\"extdisplay\" value=\"process\" />";
		
		echo "\t<script type=\"text/javascript\"> var moduleActions = new Array(); </script>\n";
		
		$actionstext = array();
		$force_actionstext = array();
		$errorstext = array();
		foreach ($moduleaction as $module => $action) {	
			$text = false;
			$skipaction = false;

			// make sure name is set. This is a problem for broken modules
			if (!isset($modules[$module]['name'])) {
				$modules[$module]['name'] = $module;
			}
			$nai_ver_ = getor($modules[$module]['naiver']);
			switch ($action) {
				case 'install':
					if (!EXTERNAL_PACKAGE_MANAGEMENT) {
						if (is_array($errors = module_checkdepends($modules[$module]))) {
							$skipaction = true;
							$errorstext[] = sprintf((($modules[$module]['status'] == MODULE_STATUS_NEEDUPGRADE) ?  _("%s cannot be upgraded: %s Please try again after the dependencies have been installed.") : _("%s cannot be installed: %s Please try again after the dependencies have been installed.") ),  
							                        $modules[$module]['name'],
							                        '<ul><li>'.implode('</li><li>',$errors).'</li></ul>');
						} else {
							if ($modules[$module]['status'] == MODULE_STATUS_NEEDUPGRADE) {
								$actionstext[] =  sprintf(_("%s %s will be upgraded to %s"), $modules[$module]['name'], $modules[$module]['dbversion'], $modules[$module]['version']);
							} else {
								$actionstext[] =  sprintf(_("%s %s will be installed and enabled"), $modules[$module]['name'], $modules[$module]['version']);
							}
						}
					}
				break;
				case 'enable':
					if (is_array($errors = module_checkdepends($modules[$module]))) {
						$skipaction = true;
						$errorstext[] = sprintf(_("%s cannot be enabled: %s Please try again after the dependencies have been installed."),  
						                        $modules[$module]['name'],
						                        '<ul><li>'.implode('</li><li>',$errors).'</li></ul>');
					} else {
						$actionstext[] =  sprintf(_("%s %s will be enabled"), $modules[$module]['name'], $modules[$module]['dbversion']);
					}
				break;
				case 'disable':
					if (is_array($errors = module_reversedepends($modules[$module]))) {
						$skipaction = true;
						$errorstext[] = sprintf(_("%s cannot be disabled because the following modules depend on it: %s Please disable those modules first then try again."),  
						                        $modules[$module]['name'],
						                        '<ul><li>'.implode('</li><li>',$errors).'</li></ul>');
					} else {
						$actionstext[] =  sprintf(_("%s %s will be disabled"), $modules[$module]['name'], $modules[$module]['dbversion']);
					}
				break;
				case 'uninstall':
					if (!EXTERNAL_PACKAGE_MANAGEMENT) {
						if (is_array($errors = module_reversedepends($modules[$module]))) {
							$skipaction = true;
							$errorstext[] = sprintf(_("%s cannot be uninstalled because the following modules depend on it: %s Please disable those modules first then try again."),  
							                        $modules[$module]['name'],
							                        '<ul><li>'.implode('</li><li>',$errors).'</li></ul>');
						} else {
							$actionstext[] =  sprintf(_("%s %s will be uninstalled"), $modules[$module]['name'], $modules[$module]['dbversion']);
						}
					}
				break;
			}

			// If error above we skip this action so we can proceed with the others
			//
			if (!$skipaction) { //TODO
				echo "\t<script type=\"text/javascript\"> moduleActions['".$module."'] = '".$action."'; </script>\n";
			}
		}
		
		// Write out the errors, if there are additional actions that can be accomplished list those next with the choice to
		// process which will ignore the ones with errors but process the rest.
		//
		if (count($errorstext) > 0) {
			//nai_ echo "<h4>"._("Errors with selection:")."</h4>\n";
			//nai_ echo "<ul>\n";
			foreach ($errorstext as $text) {
				//nai_ echo "\t<li>".$text."</li>\n";
				echo "\t<div>".$text."</div><hr>\n";
			}
			//nai_ echo "</ul>";
		} 
    if (count($actionstext) > 0 || count($force_actionstext) > 0) {
			if (count($errorstext) > 0) {
				//nai_ echo "<h4>"._("You may confirm the remaining selection and then try the again for the listed issues once the required dependencies have been met:")."</h4>\n";
			} else {
				//nai_ echo "<h4>"._("Please confirm the following actions:")."</h4>\n";
			}
      if (count($actionstext)) {
				//nai_ echo "<h5>"._("Upgrades, installs, enables and disables:")."</h5>\n";
			  //nai_ echo "<ul>\n";
			  foreach ($actionstext as $text) {
				  //nai_ echo "\t<li>".$text."</li>\n";
				  echo "\t<div>".$text."</div><hr>\n";
			  }
			  //nai_ echo "</ul>";
      }
      if (count($force_actionstext)) {
				//nai_ echo "<h5>"._("Forced downgrades and re-installs:")."</h5>\n";
			  //nai_ echo "<ul>\n";
			  foreach ($force_actionstext as $text) {
				//nai_ echo "\t<li>".$text."</li>\n";
				echo "\t<div>".$text."</div><hr>\n";
			  }
			  //nai_ echo "</ul>";
      }
			echo '<br>';
			echo "\t<input type=\"button\" value=\""._("Confirm")."\" name=\"process\" onclick=\"process_module_actions(moduleActions);\" />";
		} else {
			//nai_ echo "<h4>"._("No actions to perform")."</h4>\n";
			//nai_ echo "<p>"._("Please select at least one action to perform by clicking on the module, and selecting an action on the \"Action\" tab.")."</p>";
		}
		echo "\t<input class=\"none\" type=\"button\" value=\""._("Cancel")."\" onclick=\"location.href = 'config.php?display=modules&amp;type=$type&amp;online=$online';\" />";
		

		
		
		echo "</form>";
		
	break;
	case 'online':
	default:
		
		uasort($modules, 'category_sort_callback');


		echo "<form name=\"modulesGUI\" id=\"modulesGUI\" action=\"config.php\" method=\"post\">";
		echo "<input type=\"hidden\" name=\"display\" value=\"".$display."\" />";
		echo "<input type=\"hidden\" name=\"type\" value=\"".$type."\" />";
		echo "<input type=\"hidden\" name=\"online\" value=\"".$online."\" />";
		echo "<input type=\"hidden\" name=\"extdisplay\" value=\"confirm\" />";
		
		echo "<div class=\"modulebuttons\">";
		if ($online) {
			echo "\t<a href=\"javascript:void(null);\" onclick=\"check_download_all();\">"._("Download all")."</a>";
			echo "\t<a href=\"javascript:void(null);\" onclick=\"check_upgrade_all();\">"._("Upgrade all")."</a>";
		}
		//nai_ echo "\t<input type=\"reset\" value=\""._("Reset")."\" />";
		//nai_ echo "\t<input type=\"submit\" value=\""._("Process")."\" name=\"process\" />";
		echo "</div>";
		// nai_{
		echo '<label> <span class="icon icon-ok-sign s18 green"></span> نصب شده </label> | ';
		echo '<label> <span class="icon icon-ok-sign s18 gray"></span> نصب نشده </label> | ';
		echo '<label> <span class="icon icon-remove-sign s18 mindark"></span> غیر فعال </label> | ';
		echo '<label> <span class="icon icon-warning s15 red"></span> با مشکل مواجه شده </label> ';
		// } nai_

		echo "<div id=\"modulelist\">\n";
		/*
		echo "\t<div id=\"modulelist-header\">";
		echo "\t\t<span class=\"modulename\">"._("Module")."</span>\n";
		echo "\t\t<span class=\"moduleversion\">"._("Version")."</span>\n";
		echo "\t\t<span class=\"modulepublisher\">"._("Publisher")."</span>\n";
		echo "\t\t<span class=\"clear\">&nbsp;</span>\n";
		echo "\t</div>";
		nai_ */
		$category = false;
		$numdisplayed = 0;
		$fd = $amp_conf['ASTETCDIR'].'/freepbx_module_admin.conf';
		if (file_exists($fd)) {
			$module_filter = parse_ini_file($fd);
		} else {
			$module_filter = array();
		}
		
		
		// panel version
		global $system_xml;
		echo otag('div','class="category"');
		echo tag('h3','', 'پنل' );
		echo otag('ul');
		echo otag('li');
		echo otag('div', 'class="moduleheader"');
			echo otag('span', 'class="modulename module_cannotuninstall"');
			$mdlIcon = 'icon-ok-sign s18 green';
			$nai_ver_ = getor( $system_xml['SYSTEM']['PANEL']['NAIVER'] );
			echo
			tag('a','',
				tag('span', 'class="icon ' . $mdlIcon . '"' ).
				tag('span', 'class="mdlname"', $system_xml['SYSTEM']['PANEL']['NAME'] ).
				tag('span', 'class="mdlversion"', $nai_ver_)
			);
			echo ctag('span');
			echo tag('span','class="moduleaddress"', "admin");
		echo ctag('div');
		echo ctag('li');
		echo ctag('div');
		echo ctag('ul');
	
		foreach (array_keys($modules) as $name) {
			if (!isset($modules[$name]['category'])) {
				$modules[$name]['category'] = _("Broken");
				$modules[$name]['name'] = $name;
			}
			if (isset($module_filter[$name]) && strtolower(trim($module_filter[$name])) == 'hidden') {
				continue;
			}

      // Theory: module is not in the defined repos, and since it is not local (meaning we loaded it at some point) then we
      //         don't show it. Exception, if the status is BROKEN then we should show it because it was here once.
      //
      if ((!isset($active_repos[$modules[$name]['repo']]) || !$active_repos[$modules[$name]['repo']]) 
        && $modules[$name]['status'] != MODULE_STATUS_BROKEN && !isset($modules_local[$name])) {
        continue;
      }

      // If versionupgrade module is present then allow it to skip modules that should not be presented
      // because an upgrade is in process. This can help assure only safe modules are present and
      // force the user to upgrade in the proper order.
      //
      if (function_exists('versionupgrade_allowed_modules') && !versionupgrade_allowed_modules($modules[$name])) {
        continue;
      }
			$numdisplayed++;
			
			if ($category !== $modules[$name]['category']) {
				// show category header
				if ($category !== false) {
					// not the first one, so end the previous blocks
					echo ctag('div');
				}
				
				// start a new category header, and associated html blocks
				$category = $modules[$name]['category'];
				echo otag('div','class="category" id="category_'.prep_id($category).'"');
				echo tag('h3','',_($category));
				echo otag('ul');
			}

			$loc_domain = $name;
			$name_text = modgettext::_($modules[$name]['name'], $loc_domain);

			//echo "\t\t<li id=\"module_".prep_id($name)."\" onclick=\"toggleInfoPane('module_".prep_id($name)."');\"  >\n";
			echo otag('li', 'id="module_'. prep_id($name) . '"');
			// ---- module header 
			$salert = isset($modules[$name]['vulnerabilities']);
			$mclass = $salert ? "modulevulnerable" : "moduleheader";
			if ($salert) {
				foreach ($modules[$name]['vulnerabilities']['vul'] as $vul) {
					$security_issues_to_report[$vul] = true;
				}
			}
			//echo "\t\t<div class=\"$mclass\" onclick=\"toggleInfoPane('infopane_".prep_id($name)."');\" >\n";
			//echo "\t\t<div class=\"$mclass\" >\n";
			echo otag('div', 'class="'. $mclass . '"');
			
			$module_cannotuninstall = $modules[$name]['canuninstall']=='no'?'module_cannotuninstall':''; // nai_ for no uninstall modules
			//echo "\t\t\t<span class=\"modulename $module_cannotuninstall\" title=\"$name\">";
			echo otag('span', 'class="modulename '. $module_cannotuninstall . '" title="'. $name .'"');
			
	
			$mdlIcon = null;
			switch ($modules[$name]['status']) {
				case MODULE_STATUS_NOTINSTALLED:
					if (isset($modules_local[$name]))
						$mdlIcon = ' icon-ok-sign s18 gray';
				break;
				case MODULE_STATUS_DISABLED:
					$mdlIcon = ' icon-remove-sign s18 mindark';
				break;
				case MODULE_STATUS_NEEDUPGRADE:
					$mdlIcon = ' icon-warning  s15 alert2';
				break;
				case MODULE_STATUS_BROKEN:
					$mdlIcon = ' icon-warning s15 red';
				break;
				default:
					$mdlIcon = ' icon-ok-sign s18 green';

				break;
			}
			

			$nai_ver_ = getor($modules[$name]['naiver']);
			
			echo
			tag('a','',
				tag('span', 'class="icon ' . $mdlIcon . '"' ).
				tag('span', 'class="mdlname"', getor($name_text, $name) ).
				tag('span', 'class="mdlversion"', $nai_ver_)
			)
			;
			
		
			echo ctag('span');

			
			echo tag('span','class="moduleaddress"', "$name");

			
			echo ctag('div');
			
			// ---- end of module header
			
			// ---- drop-down tab box thingy:
			echo otag('div','class="moduleinfopane" id="infopane_'.prep_id($name).'"');
 
			echo tag('label','data-hich=true',
				tag('input','type="radio" data-hich=true data-module="'.prep_id($name).'" checked id="noaction_'.prep_id($name).'" name="moduleaction['.prep_id($name).']" value="0"').
				' هیج عملیاتی صورت نگیرد '
			);
			
			switch ($modules[$name]['status']) {
				case MODULE_STATUS_NOTINSTALLED:
					if (!EXTERNAL_PACKAGE_MANAGEMENT) {
						if (isset($modules_local[$name])) {
							echo tag('label','',
								tag('input','type="radio" id="install_'.prep_id($name).'" name="moduleaction['.prep_id($name).']" value="install"').
								' نصب '
							);
						}
					}
				break;
				case MODULE_STATUS_DISABLED:
					echo tag('label','',
						tag('input','type="radio" id="enable_'.prep_id($name).'" name="moduleaction['.prep_id($name).']" value="enable"').
						' فعال کردن '
					);
					if (!EXTERNAL_PACKAGE_MANAGEMENT) {
						echo tag('label','',
							tag('input','type="radio" id="uninstall_'.prep_id($name).'" name="moduleaction['.prep_id($name).']" value="uninstall"').
							' حذف '
						);
					}
				break;
				case MODULE_STATUS_NEEDUPGRADE:
					if (!EXTERNAL_PACKAGE_MANAGEMENT) {
						echo tag('label','',
							tag('input','type="radio" id="install_'.prep_id($name).'" name="moduleaction['.prep_id($name).']" value="install"').
							' بروز رسانی '
						);
						echo tag('label','',
							tag('input','type="radio" id="uninstall_'.prep_id($name).'" name="moduleaction['.prep_id($name).']" value="uninstall"').
							' حذف '
						);
					}
				break;
				case MODULE_STATUS_BROKEN:
					if (!EXTERNAL_PACKAGE_MANAGEMENT) {
						echo tag('label','',
							tag('input','type="radio" id="install_'.prep_id($name).'" name="moduleaction['.prep_id($name).']" value="install"').
							' نصب '
						);
						echo tag('label','',
							tag('input','type="radio" id="uninstall_'.prep_id($name).'" name="moduleaction['.prep_id($name).']" value="uninstall"').
							' حذف '
						);
					}
				break;
				default:
					if (enable_option($name,'candisable')) {
						echo tag('label','',
							tag('input','type="radio" id="disable_'.prep_id($name).'" name="moduleaction['.prep_id($name).']" value="disable"').
							' غیرفعال کردن '
						);
					}
					if (!EXTERNAL_PACKAGE_MANAGEMENT && enable_option($name,'canuninstall')) {
						echo tag('label','',
							tag('input','type="radio" id="uninstall_'.prep_id($name).'" name="moduleaction['.prep_id($name).']" value="uninstall"').
							' حذف '
						);
					}
				break;
			}

			echo ctag('div');
			
			// ---- end of drop-down tab box 
			
			echo ctag('li');
		}
		
		if ($numdisplayed == 0) {
			if (isset($modules_online) && count($modules_online) > 0) {
				echo _("All available modules are up-to-date and installed.");
			} else {
				echo _("No modules to display.");
			}
		}
		
		echo "\t</ul></div>\n";
		echo "</div>";

		echo "<div class=\"modulebuttons\">";
		
		echo "\t<input type=\"submit\" value=\""._("Process")."\" name=\"process\" /> | ";
		echo "\t<button type=\"reset\" class=\"none\">". _("Reset")."</button>";
		
		echo "</div>";

		echo "</form>";
	break;
}
if (!empty($security_issues_to_report)) {
	foreach (array_keys($security_issues_to_report) as $id) {
		if (!is_array($security_array[$id]['related_urls']['url'])) {
			$security_array[$id]['related_urls']['url'] = array($security_array[$id]['related_urls']['url']);
		}
		$tickets = preg_replace_callback('/(?<!\w)(?:#|bug |ticket )([^&]\d{3,4})(?!\w)/i', 'trac_replace_ticket', $security_array[$id]['tickets']);
?>
-
<?php
	}
}

if ($quietmode) {
	echo '</body></html>';
}

//-------------------------------------------------------------------------------------------
// Help functions
//

function category_sort_callback($a, $b) {
	if (!isset($a['category']) || !isset($b['category'])) {
		if (!isset($a['name']) || !isset($b['name'])) {
			return 0;
		} else {
			return strcmp($a['name'], $b['name']);
		}
	}
	// sort by category..
	$catcomp = strcmp($a['category'], $b['category']);
	if ($catcomp == 0) {
		// .. then by name
		return strcmp($a['name'], $b['name']);
	} elseif ($a['category'] == 'Basic') {
			return -1;
	} elseif ($b['category'] == 'Basic') {
		return 1;
	} else {
		return $catcomp;
	}
}

/** preps a string to use as an HTML id element
 */
function prep_id($name) {
	return preg_replace("/[^a-z0-9-]/i", "_", $name);
}


/* enable_option($module_name, $option)
   This function will return false if the particular option, which is a module xml tag,
	 is set to 'no'. It also provides for some hardcoded overrides on critical modules to
	 keep people from editing the xml themselves and then breaking their the system.
*/
function enable_option($module_name, $option) {
	global $modules;

	$enable=true;
	$override = array('core'      => array('candisable' => 'no',
	                                       'canuninstall' => 'no',
					                              ),
	                  'framework' => array('candisable' => 'no',
	                                       'canuninstall' => 'no',
																			  ),
	                 );
	if (isset($modules[$module_name][$option]) && strtolower(trim($modules[$module_name][$option])) == 'no') {
		$enable=false;
	}
	if (isset($override[$module_name][$option]) && strtolower(trim($override[$module_name][$option])) == 'no') {
		$enable=false;
	}
	return $enable;
}

/* Replace '#nnn', 'bug nnn', 'ticket nnn' type ticket numbers in changelog with a link, taken from Greg's drupal filter
*/
function trac_replace_ticket($match) {
  $baseurl = 'http://freepbx.org/trac/ticket/';
  return '<a target="tractickets" href="'.$baseurl.$match[1].'" title="ticket '.$match[1].'">'.$match[0].'</a>';
}

/* Replace 'rnnn' changeset references to a link, taken from Greg's drupal filter
*/
function trac_replace_changeset($match) {
  $baseurl = 'http://freepbx.org/trac/changeset/';
  return '<a target="tractickets" href="'.$baseurl.$match[1].'" title="changeset '.$match[1].'">'.$match[0].'</a>';
}                                                                                                                                              

function pageReload(){
	return "";
	//return "<script language=\"Javascript\">document.location='".$_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING']."&foo=".rand()."'</script>";
}

function displayRepoSelect($buttons) {
  global $display, $type, $online, $tabindex;
  global $active_repos;

  $standard_repo = true;
  $extended_repo = true;
  $unsupported_repo = false;
  $commercial_repo = true;

  $button_display = '';
  $href = "config.php?display=$display&type=$type";
  $button_template = '<input type="button" value="%s" onclick="location.href=\'%s\';" />'."\n";



  $tooltip  = _("Choose the repositories that you want to check for new modules. Any updates available for modules you have on your system will be detected even if the repository is not checked. If you are installing a new system, you may want to start with the Basic repository and upload all modules, then go back and review the others.").' ';
  $tooltip .= _(" The modules in the Extended repository are less common and may receive lower levels of support. The Unsupported repository has modules that are not supported by the FreePBX team but may receive some level of support by the authors.").' ';
  $tooltip .= _("The Commercial repository is reserved for modules that are available for purchase and commercially supported.").' ';
  $tooltip .= '<br /><br /><small><i>('._("Checking for updates will transmit your FreePBX, Distro, Asterisk and PHP version numbers along with a unique but random identifier. This is used to provide proper update information and track version usage to focus development and maintenance efforts. No private information is transmitted.").')</i></small>';
?>
  <form name="onlineRepo" action="config.php" method="post">
    <?php echo $button_display ?>
  </form>
<?php
}
?>
</div>
<script> <!-- nai_ kolle in tag -->
	$(function(){
		$(document).keypress(function(e){
			if( e.shiftKey && (e.key=='i' || e.key=='I') ){
				alert( 'گزینه نصب برای تمام ماژول ها انتخاب شد.' );
				$('input[type=radio][value=install]').attr('checked','checked');
			}
			else if( e.shiftKey && (e.key=='u' || e.key=='U') ){
				alert( 'گزینه حذف برای تمام ماژول ها انتخاب شد.' );
				$('input[type=radio][value=uninstall]').attr('checked','checked');
			}
		});
		

		$('.moduleinfopane input[type=radio]').change(function(){
			var pr = $(this).parent('label').parent('.moduleinfopane');
			pr.attr('data-naiclass', $(this).val() );
		});
		
		
		$('input[type=radio][data-hich]').change(function(){
			$(this).parent('label').removeClass('show');
		});
		$('input[type=radio]:not([data-hich])').change(function(){
			$(this).parent('label').parent('div').find('label[data-hich]').addClass('show')
		});
	});
</script>