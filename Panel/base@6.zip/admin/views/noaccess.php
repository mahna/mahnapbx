<div id="login_form" class="calert">
<?php
	global $hasper;
	
	if($hasper === false){
		echo '<div class="title"> <span class="icon-locked2 s18 icon"></span> محدودیت دسترسی</div>';
		echo otag('table');
		echo tag('tr','',tag('td','','گروه شما مجاز به دسترسی به این بخش نیست.'));
		echo ctag('table');
	}
	else{
		echo '<div class="title"> <span class="icon-warning s18 icon"></span> محدودیت دسترسی</div>';
		echo otag('table');
		echo tag('tr','',tag('td','','گروه شما مجاز به دسترسی کامل به این بخش نیست. قسمت های قابل دسترسی عبارت اند از:'));
		echo otag('tr');
		echo otag('td');
			foreach($hasper as $link){
				echo tag('span','class="item"','<span class="icon-ok-sign green s18 icon"></span>'.$link);
			}
		echo ctag('tr');
		echo ctag('td');
		echo ctag('table');
	}
?>
</div>