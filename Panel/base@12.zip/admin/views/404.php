<div id="login_form" class="calert">

		<div class="title"> <span class="icon-warning s18 icon"></span> خطای 404 </div>

		<table>
		<tr>
			<td>
				ماژولی با نام <?php echo $_GET['display']; ?> در سیستم موجود نیست.
			</td>
		</tr>
		</table>


</div>