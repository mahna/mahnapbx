global.http		= require ( 'http' ).createServer( ).listen( 1000, function(){
	//console.log('listening on *:1000');
} );

global.io		= require ( 'socket.io' ) ( http );

global.mysql	= require( 'mysql' );
global.db		= mysql.createConnection({ host: 'localhost',user: 'root',password: ''} );
db.connect( function(err){} );

global.ami 		= new require('asterisk-manager')( 5038,'localhost','admin','amp111', true);

var naiAmi_		= require('nai-asterisk-manager');
global.naiAmi	= naiAmi_.connect( 5038,'localhost','admin','amp111');


global.CronJob = require('cron').CronJob;

global.os          = require ('os');
global.exec        = require ('child_process').exec;
global.async       = require ('async');
global.fs = require('fs');
global.colors = require('colors');

global.Number.prototype.padLeft = function(base,chr){
    var  len = (String(base || 10).length - String(this).length)+1;
    return len > 0? new Array(len).join(chr || '0')+this : this;
}
global.unixTime = function(){
	var x = Math.round(+new Date()/1000);
	return x;
}
global.getTime = function(dayCalc){
	if( typeof dayCalc == 'undefined' ) dayCalc = 0;
	var d = new Date();
	d.setDate(d.getDate() + dayCalc);
	var dformat = [d.getFullYear().padLeft(),
				   (d.getMonth()+1).padLeft(),
				   d.getDate()].join('-') +' ' +
				  [d.getHours().padLeft(),
				   d.getMinutes().padLeft(),
				   d.getSeconds().padLeft()].join(':');
	return dformat;
}
global.mysqlEscape = function(stringToEscape){
    return stringToEscape
        .replace("\\", "\\\\")
        .replace("\'", "\\\'")
        .replace("\"", "\\\"")
        .replace("\n", "\\\n")
        .replace("\r", "\\\r")
        .replace("\x00", "\\\x00")
        .replace('"', "")
        .replace("'", "")
        .replace("\x1a", "\\\x1a");
}
global.secToTime = function(totalSec){
	var hours = parseInt( totalSec / 3600 ) % 24;
	var minutes = parseInt( totalSec / 60 ) % 60;
	var seconds = totalSec % 60;
	return (hours < 10 ? "0" + hours : hours) + ":" + (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds  < 10 ? "0" + seconds : seconds);
}



require('node-import');

naiAmi.on('newCall',function(data){
	console.log('New Call: '.green	, (data.uniqueid).bold, data.calleridnum + ' -> ' + data.connectedlinenum);
});
naiAmi.on('endCall',function(data){
	console.log('End Call: '.red	, (data.uniqueid).bold);
});


db.query("SELECT * FROM `asterisk`.`modules` WHERE `enabled` = '1'",function(err,result){
	if(err) console.log( err );
	var path;
	for( var i = 0; i < result.length; i++ ){
		nodeJsFile = '../modules/'+result[i].modulename+'/nodejs/index.js';
		ifExistsThenImport( nodeJsFile );
		
		
	}
});
function ifExistsThenImport(file){
	fs.exists(file, function(exists) {
		if (exists) {
			imports(file);
			console.log(file.gray, 'started!'.green.bold  );
		}
	});
}