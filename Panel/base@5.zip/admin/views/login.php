<?php
$html = null;

$html .= '<div id="login_form" class="calert">';
$html .= '<div class="title"> <span class="icon-key s18 icon"></span> ورود به سیستم</div>';
if ($errors) {
	$html .= '<div class="obe_error">';
	foreach($errors as $error){
		$html.= "<div class=\"error\"> <span class=\"icon-warning s22 icon\"></span> $error  </div>";
	}

	$html .= '</div>';
}
$html .= '<table>';
	$html .= form_open($_SERVER['REQUEST_URI'], 'id="loginform"');

	$html .= '<tr>';
		$html .= '<td>';
			
			$html .= 'نام کاربری : ';
		$html .= '</td>';
		$html .= '<td>';
			$html .= form_input(array('name'=>'username','class'=>'widthfull'));
		$html .= '</td>';
	$html .= '</tr>';
	$html .= '<tr>';
		$html .= '<td>';
			$html .= 'رمز عبور : ';
		$html .= '</td>';
		$html .= '<td>';
			$html .= form_input(array('name'=>'password','type'=>'password','class'=>'widthfull'));
		$html .= '</td>';
	$html .= '</tr>';
	
	$html .= '<tr>';
		$html .= '<td colspan="2" style="text-align:left;">';
			$html .= form_submit('submit', _('ورود'));
		$html .= '</td>';
	$html .= '</tr>';
	
	$html .= form_close();
$html .= '</table>';

$html .= '</div>';

$html .= br(5) . '<div id="key" style="color: white;font-size:small">'
	  . session_id()
	  . '</div>';

$html .= '<script type="text/javascript" src="assets/js/views/login.js"></script>';

echo $html;

?>
