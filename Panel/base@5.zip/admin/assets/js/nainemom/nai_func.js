var nodeSocket = io.connect(':1000');

jQuery.fn.outerHTML = function(s) {
    return s
        ? this.before(s).remove()
        : jQuery("<p>").append(this.eq(0).clone()).html();
};
// Popup window code
function newPopup(url,width,height) {
	popupWindow = window.open(
		url,'popUpWindow','height='+height+',width='+width+',left=10,top=10,resizable=no,scrollbars=no,toolbar=no,menubar=no,location=no,directories=no,status=yes')
}
function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+d.toGMTString();
    document.cookie = cname + "=" + cvalue + "; " + expires;
}
function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i].trim();
        if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
    }
    return "";
} 
function scrollToBottom($elem){
	var elem    = $elem[0];
	var height = elem.scrollHeight;
	$elem.scrollTop(height);
}
function scrollToTop($elem){
	var elem    = $elem[0];
	$elem.scrollTop(0);
}
function naiHide($elem){
	$elem.addClass('hidden');
}
function naiShow($elem){
	$elem.removeClass('hidden');
}

function chosenRefresh(){
	$('select.chosen').trigger('chosen:updated');$('select.chosen').trigger('liszt:updated');
}
