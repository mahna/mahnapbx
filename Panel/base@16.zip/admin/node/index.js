global.http		= require ( 'http' ).createServer().listen( 1000, function(){
	//console.log('listening on *:1000');
} );

global.io		= require ( 'socket.io' ) ( http );

global.mysql	= require( 'mysql' );
global.db		= mysql.createConnection({ host: 'localhost',user: 'root',password: ''} );
db.connect( function(err){} );

global.ami 		= new require('asterisk-manager')( 5038,'localhost','admin','amp111', true);

var naiAmi_		= require('nai-asterisk-manager');
global.naiAmi	= naiAmi_.connect( 5038,'localhost','admin','amp111');

global.events = require('events');

global.CronJob = require('cron').CronJob;

global.os          = require ('os');
global.exec        = require ('child_process').exec;
global.async       = require ('async');
global.fs = require('fs');
global.colors = require('colors');

global.Number.prototype.padLeft = function(base,chr){
    var  len = (String(base || 10).length - String(this).length)+1;
    return len > 0? new Array(len).join(chr || '0')+this : this;
}
global.unixTime = function(){
	var x = Math.round(+new Date()/1000);
	return x;
}
global.getTime = function(dayCalc){
	if( typeof dayCalc == 'undefined' ) dayCalc = 0;
	var d = new Date();
	d.setDate(d.getDate() + dayCalc);
	var dformat = [d.getFullYear().padLeft(),
				   (d.getMonth()+1).padLeft(),
				   d.getDate()].join('-') +' ' +
				  [d.getHours().padLeft(),
				   d.getMinutes().padLeft(),
				   d.getSeconds().padLeft()].join(':');
	return dformat;
}
global.mysqlEscape = function(stringToEscape){
    return stringToEscape
        .replace("\\", "\\\\")
        .replace("\'", "\\\'")
        .replace("\"", "\\\"")
        .replace("\n", "\\\n")
        .replace("\r", "\\\r")
        .replace("\x00", "\\\x00")
        .replace('"', "")
        .replace("'", "")
        .replace("\x1a", "\\\x1a");
}
global.secToTime = function(totalSec){
	var hours = parseInt( totalSec / 3600 ) % 24;
	var minutes = parseInt( totalSec / 60 ) % 60;
	var seconds = totalSec % 60;
	return (hours < 10 ? "0" + hours : hours) + ":" + (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds  < 10 ? "0" + seconds : seconds);
}
global.findByKey = function (source, key, value) {
	for (var i = 0; i < source.length; i++)
		if (source[i][key] === value)
			return source[i];
	return false;
}

global.isModuleInstalled = function(moduleName,callback){
	var query = 'SELECT `modulename` FROM `asterisk`.`modules` WHERE `modulename` = \''+mysqlEscape(moduleName)+'\' AND `enabled` = 1;';
	db.query( query ,function(err,result){
		if(err) console.log( err );
		if( typeof result.length != 'undefined' )
			callback( result.length>0?true:false );
		else
			callback( false );
	});
}

global.getUserGroups = function(userId,callback){
	var query = 'SELECT `group_id` FROM `asterisk`.`group_members` WHERE `user_id` = \''+userId+'\' GROUP BY `group_id`;';
	db.query( query ,function(err,result){
		if(err) console.log( err );
		if( typeof result.length != 'undefined' )
			callback( result );
		else
			callback( false );
	});
}
global.moduleAccessOptions = function( moduleName, userId, callback ){
		if( userId == 1 ){
			callback( true );
			return;
		}
		var permissions_to_this_page = [];
		getUserGroups(userId, function(userGroups){
			if( userGroups === false ){
				callback( false );
				return;
			}
			var groupIn = "";
			var sp = '';
			for( i = 0; i < userGroups.length; i++ ){
				groupIn+= sp + userGroups[i]['group_id'];
				sp = ', ';
			}
			db.query( "SELECT * FROM `asterisk`.`permission` WHERE group_id IN("+groupIn+") AND `name` = '"+moduleName+"' AND web_resource = TRUE GROUP BY `in_permission`;", function(err, result){
				for(j = 0; j<result.length; j++){
					if( !result[j]['in_permission'] ){
						callback( true );
						return;
					}
					else{
						if( permissions_to_this_page.indexOf( result[j]['in_permission'] ) == -1 )
							permissions_to_this_page.push( result[j]['in_permission'] );
					}
				}
				callback( permissions_to_this_page );
				return;
			});
		});
}


db.query("SELECT * FROM `asterisk`.`modules` WHERE `enabled` = '1'",function(err,result){
	if(err) console.log( err );
	var path;
	for( var i = 0; i < result.length; i++ ){
		nodeJsFile = '../modules/'+result[i].modulename+'/nodejs/index.js';
		ifExistsThenImport( nodeJsFile );
		
		
	}
});
function ifExistsThenImport(file){
	fs.exists(file, function(exists) {
		if (exists) {
			console.log(file.gray, 'started!'.green.bold  );
			//imports(file);
			require(file);
			
			
		}
	});
}