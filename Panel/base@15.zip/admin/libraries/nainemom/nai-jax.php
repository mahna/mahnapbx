<?php
	// clean page
	ob_clean();
	
	// set header
	header('Content-Type: application/json; charset=utf-8');
	
	// parameters
	$naijaxClass = getor( $_GET['class'] );
	$naijaxObject = getor( $_GET['object'] );
	$naijaxFunction = getor( $_GET['function'] );
	$naijaxMethod = getor( $_GET['method'] );
	$naijaxEmpty = '::naijaxEmpty::'. microtime(); // the unique empty variable if data not send
	$parameters = getor($_GET['parameters'], $naijaxEmpty);
	
	// find the func
	if( $naijaxClass )
		$func = array( $naijaxClass, $naijaxMethod);
	else if( $naijaxObject )
		$func = array( ${$naijaxObject}, $naijaxMethod);
	else
		$func = $naijaxFunction;
	
	// call function and put response to $ret variable
	if( $parameters === $naijaxEmpty )
		$ret = call_user_func( $func );
	else
		$ret = call_user_func_array( $func, $parameters );
	//print_r($parameters);
	//exit;
	// print output
	echo json_encode( $ret );
	exit;
?>