/**
 * Grid theme for Highcharts JS
 * @author Torstein Honsi
 */

Highcharts.theme = {
   colors: ['#E67E22', '#27AE60', '#C0392B', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263', '#6AF9C4'],
   chart: {
      backgroundColor: 'transparent',
      borderWidth: 0,
      plotBackgroundColor: 'rgba(0, 0, 0, .0)',
      plotShadow: false,
      plotBorderWidth: 0
   },
   title: {
      style: {
         color: '#464646',
         font: 'bold 12px Tahoma'
      }
   },
   subtitle: {
      style: {
         color: '#666666',
         font: '12px Tahoma'
      }
   },
   xAxis: {
      gridLineWidth: 1,
	  gridLineColor: '#B7CFDF',
      lineColor: '#464646',
      tickColor: '#464646',
      lineWidth: 1,
      tickWidth: 1,
      labels: {
         style: {
			margin: '0px auto',
            color: '#464646',
            font: '12px Tahoma'
         }
      },
      title: {
         style: {
            color: '#333',
            fontWeight: 'bold',
            fontSize: '12px',
            font: 'Tahoma'

         }
      }
   },
   yAxis: {
      minorTickInterval: 'auto',
      /* gridLineWidth: 1, */
	  gridLineColor: '#B7CFDF',
      lineColor: '#464646',
      lineWidth: 1,
      tickWidth: 1,
      tickColor: '#464646',
      labels: {
         style: {
            color: '#464646',
            font: '12px Tahoma'
         }
      },
      title: {
         style: {
            color: '#333',
            fontWeight: 'bold',
            fontSize: '12px',
            fontFamily: 'Tahoma'
         }
      }
   },
   legend: {
      itemStyle: {
         font: '9pt Tahoma',
         color: '#464646'

      },
      itemHoverStyle: {
         color: '#039'
      },
      itemHiddenStyle: {
         color: 'gray'
      }
   },
   labels: {
      style: {
         color: '#99b'
      }
   },

   navigation: {
      buttonOptions: {
         theme: {
            stroke: '#CCCCCC'
         }
      }
   }
};

// Apply the theme
var highchartsOptions = Highcharts.setOptions(Highcharts.theme);