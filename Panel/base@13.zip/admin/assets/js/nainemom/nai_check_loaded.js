var loaded = false;

window.onload = function(){ // maybe not, but when happened, its before onpageshow and means document correct loaded
	loaded = true;
}

window.onpageshow = function(){  // always fired after onload
	if( !loaded ){
		document.getElementsByTagName('body')[0].className = 'hidden';
		window.location.reload();
	}
}