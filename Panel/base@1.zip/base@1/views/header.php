
<?php
global $user;
$version			= get_framework_version();
$version_tag		= '?load_version=' . urlencode($version);
if ($amp_conf['FORCE_JS_CSS_IMG_DOWNLOAD']) {
	$this_time_append	= '.' . time();
	$version_tag 		.= $this_time_append;
} else {
	$this_time_append = '';
}

//set language to persian AND setting *NEW
$amp_conf['DISABLE_CSS_AUTOGEN'] = true;
$amp_conf['USE_GOOGLE_CDN_JS'] = false;
$_COOKIE['lang'] = 'fa_IR';
setcookie("lang", 'fa_IR', time()+365*24*60*60);

//html head
echo '<!DOCTYPE html>';
echo '<html>';
echo '<head>';

global $module_page;
$mdl = nai_mymodulesadmin_getmodule($module_page);

$system_xml_file_address = file_get_contents( 'system.xml');
$system_xml = XMLtoArray($system_xml_file_address);

$panel_name = $system_xml['SYSTEM']['PANEL']['NAME'];
$panel_minname = $system_xml['SYSTEM']['PANEL']['MINNAME'];
$panel_logo = $system_xml['SYSTEM']['PANEL']['LOGO'];
$panel_titleicon = $system_xml['SYSTEM']['PANEL']['TITLEICON'];
	
	
if($mdl['title'])
	echo "<title> $panel_minname | $mdl[title] </title>";
else
	echo "<title> $panel_name </title>";

echo '<meta http-equiv="Content-Type" content="text/html;charset=utf-8">'
		. '<meta http-equiv="Content-Type" content="text/html;charset=utf-8">'
		. '<meta http-equiv="X-UA-Compatible" content="chrome=1">'
		. '<meta name="robots" content="noindex" />'
		. '<meta charset="UTF-8">'
		. '<link rel="shortcut icon" href="' . $panel_titleicon . '">'
		;


//add the popover.css stylesheet if we are displaying a popover to override mainstyle.css styling
if ($use_popover_css) {
	$popover_css = $amp_conf['BRAND_CSS_ALT_POPOVER'] ? $amp_conf['BRAND_CSS_ALT_POPOVER'] : 'assets/css/popover.css';
	echo '<link href="' . $popover_css.$version_tag . '" rel="stylesheet" type="text/css">';
}


echo '<link href="assets/css/mainstyle.css" rel="stylesheet" type="text/css">';
echo '<link href="assets/css/jquery-ui.css" rel="stylesheet" type="text/css">';


echo '<script type="text/javascript" src="assets/js/jquery-1.7.1.min.js"></script>';
echo '<script type="text/javascript" src="assets/js/jquery-ui-1.8.9.min.js"></script>';


echo '<link href="assets/css/nainemom/icomoon.css" rel="stylesheet" type="text/css">';

echo '<link href="assets/nai_plugin/chosen/chosen.css" rel="stylesheet" type="text/css">';
echo '<script src="assets/nai_plugin/chosen/chosen.jquery.js"></script>';


echo '<script src="assets/nai_plugin/persianDatepicker/js/persianDatepicker.js"></script>';
echo '<link type="text/css" rel="stylesheet" href="assets/nai_plugin/persianDatepicker/css/persianDatepicker-default.css" />';

echo '<script src="assets/nai_plugin/maskedinput/jquery.maskedinput.min.js"></script>';

echo '<link href="assets/nai_plugin/tipper/jquery.fs.tipper.min.css" rel="stylesheet" type="text/css">';
echo '<script src="assets/nai_plugin/tipper/jquery.fs.tipper.min.js"></script>';

echo '<link href="assets/nai_plugin/onoff/jquery.onoff.css" rel="stylesheet" type="text/css">';
echo '<script src="assets/nai_plugin/onoff/jquery.onoff.js"></script>';

echo '<link href="assets/css/nainemom/nai_style.css" rel="stylesheet" type="text/css">';


global $username;
$usrf = nai_myampusers_getuser($username);
$theme = $usrf['theme']==''?'default':$usrf['theme'];
echo '<link href="assets/css/nainemom/theme/'.$theme.'.css" rel="stylesheet" type="text/css">';




if( getor($_GET['nai_dialog']) == 'true' || getor($_GET['fw_popover']) == 1 ){
	echo '<link href="assets/css/nainemom/nai_dialog.css" rel="stylesheet" type="text/css">';
}
	
	

echo '</head>';

//open body
echo '<body>';

//echo '<div id="page">';//open page
		
		
//nai_header
$username = (isset($_SESSION['AMP_user']->username) ? $_SESSION['AMP_user']->username : 'ERROR');
$currentmodule = $display;



$alertclass = (check_reload_needed()==1?'alert':''); 
echo otag('div','id="nai_header"');
	echo otag('div','id="logo"');
		//echo tag('span','class="icon icon-logo_mahna s55 light "');
		echo stag('img',"class=\"image\" src=\"$panel_logo\"");
		echo tag('span','class="text"',$panel_name);
	echo ctag('div');
	
	if($username!='ERROR'){
		echo  otag('div','id="toppan"');
			echo otag('ul');
				echo otag('a','href="?display=index" title="صفحه اصلی"');
				echo otag('li');
					echo tag('span','class="icon-home2 icon light s28 clickable"');
					//echo tag('span','class="text clickable"','صفحه اصلی');
				echo ctag('li');
				echo ctag('a');
				global $vl;
				$user_dpname = getor($user['username'],null);
				//$_dpname = $vl->match($user_dpname,'farsi')?$user_dpname:'منوی کاربری';
				$_dpname = $user_dpname;
				
				echo otag('li','title="منوی کاربری: '.$_dpname .'" id="menu_karbari"');
					echo tag('span','class="icon-user2 icon light s28 clickable"');
					//echo tag('span','class="text clickable"', $_dpname );
					echo otag('ul');	
						echo otag('a',"href=\"?display=changepassword\"");
							echo otag('li');
								echo tag('span','class="icon-wrench icon light s22 clickable"').'تنظیمات کاربری';
							echo ctag('li');
						echo ctag('a');
						echo otag('a','id="user_logout" href="#"');
							echo otag('li');
								echo tag('span','class="icon-exit icon light s22 clickable"').'خروج';
							echo ctag('li');
						echo ctag('a');
					echo ctag('ul');
				echo ctag('li');
				$notifCount = 0;
				if($alertclass) $notifCount++;
				
				$asterisk_status = true;
				$check_asterisk = shell_exec("service asterisk status");
				if( strpos($check_asterisk,'stopped') !== false ) { $asterisk_status = false; $notifCount++; }
				
				echo otag('li',"data-notifcount=\"$notifCount\" id=\"user_menu\" title=\"اعلان ها\"");
					if($notifCount>0) echo tag('span',"class=\"notif_count\" id=\"notif_count\" data-notifCount=\"$notifCount\"",$notifCount);
					echo tag('span','class="icon-earth icon light s28 clickable"');
					//echo tag('span','class="text clickable"','اعلان ها');
					echo otag('ul');
					
						if($asterisk_status==false){
							echo otag('a',"href=\"#\"");
								echo tag('li','',tag('span','class="icon-warning icon light s22 clickable"').'استریسک غیرفعال است!');
							echo ctag('a');
						}
						
						echo otag('a',"id=\"button_reload\" href=\"#\"");
							echo tag('li','',tag('span','class="icon-check-alt icon light s22 clickable"').'اعمال تغییرات');
						echo ctag('a');



					echo ctag('ul');
				echo ctag('li');
				
				if(nai_myampusers_is_admin($username)){
					echo otag('li','title="سیستم"');
						echo tag('span','class="icon-wrench3 icon light s28 clickable" title="سیستم"');
						//echo tag('span','class="text clickable"','سیستم');
						echo otag('ul');
							
							echo otag('a',"href=\"?display=modules\"");
								echo tag('li','',tag('span','class="icon-window icon light s22 clickable"').'مدیریت ماژول ها');
							echo ctag('a');
							
							echo otag('a',"id=\"button_macpl\" href=\"config.php?display=$_GET[display]&do=shutdownserver\" onclick=\"var sure = confirm('آیا از خاموش کردن سرور مطمئن هستید؟'); if(!sure) return false;\"");
								echo tag('li','',tag('span','class="icon-switch icon light s22 clickable"').'خاموش کردن سرور');
							echo ctag('a');
							
							echo otag('a',"id=\"button_macpl\" href=\"config.php?display=$_GET[display]&do=restartserver\" onclick=\"var sure = confirm('آیا از راه اندازی مجدد سرور مطمئن هستید؟'); if(!sure) return false;\"");
								echo tag('li','',tag('span','class="icon-reload-alt icon light s22 clickable"').'راه اندازی مجدد سرور');
							echo ctag('a');
							echo otag('a',"id=\"button_macpl\" href=\"config.php?display=$_GET[display]&do=macpl\" onclick=\"var sure = confirm('آیا از پیکربندی تلفن ها مطمئن هستید؟'); if(!sure) return false;\"");
								echo tag('li','',tag('span','class="icon-phone2 icon light s22 clickable"').'پیکربندی تلفن ها');
							echo ctag('a');
						echo ctag('ul');
					echo ctag('li');
				}
				
				if( $display != 'noauth' ) nai_basemodules_includes_header();
	
				
			echo ctag('ul');
			
			
		echo ctag('div');
	}

	
echo ctag('div'); // end nai_header

