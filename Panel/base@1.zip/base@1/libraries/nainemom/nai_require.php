<?php
	include_once('jdf.php');
	include_once('nai_myclass.php');
	class nai_javascript{
		public $auto_echo = true,$script_tag = true,$jquery_function = true;
		public function return_form($data){
			$ret = '';
			foreach($data as $key=>$val){
				$element = substr( $key , 0 , strpos( $key , '-' ) );
				if( !$element && strpos( $key , '-' ) ) $element = 'none';
				switch( $element ){
					case 'checkbox':
						if( $val ){
							if(is_array($val)){
								foreach($val as $key_=>$val_){
									$_key = $key.'['.$key_.']';
									$ret .= "$('[name=\"$_key\"]').attr('checked','checked').change(); \n";
								}
							}
							else{
								$ret .= "$('[name=\"$key\"]').attr('checked','checked').change(); \n";
							}
						}
						break;
					case 'radio':
						$ret .= "$('[name=\"$key\"][value=\"$val\"]').attr('checked','checked').change(); \n";
						break;
					case 'text': case 'none': case 'hidden':
						$ret .= "$('[name=\"$key\"]').val('$val').change(); \n";
						break;
					case 'select':
						if(is_array($val)){
							$_key = $key.'[]';
							$_val = "[";
							$sp='';
							foreach($val as $x){
								$_val.= "$sp'$x'";
								$sp=',';
							}
							$_val.= "]";
							$ret .= "$('[name=\"$_key\"]').val($_val).change(); \n";
						}
						else{
							$ret .= "$('[name=\"$key\"]').children('option[value=\"$val\"]').eq(0).attr('selected','selected'); \n";
							break;
						}
					case 'textarea':
						$_val = rawurlencode($val);
						$ret .= "$('[name=\"$key\"]').val(decodeURIComponent('$_val')).change(); \n";
						break;
				}
			}
			$ret .= "$('select.chosen').trigger('chosen:updated');$('select.chosen').trigger('liszt:updated'); \n";
			
			if($this->jquery_function) $ret = '$(function(){' . $ret . '});';
			if($this->script_tag) $ret = '<script>' . $ret . '</script>';
			if($this->auto_echo) echo $ret; else return $ret;
		}
		public function alert($text){
			$ret = '';
			$text_ = str_replace('\'','\\\'',$text);
			$ret.= "alert('$text_');";
			if($this->jquery_function) $ret = '$(function(){' . $ret . '});';
			if($this->script_tag) $ret = '<script>' . $ret . '</script>';
			if($this->auto_echo) echo $ret; else return $ret;
		}
		public function script($code){
			$ret = '';
			$ret.= $code;
			if($this->jquery_function) $ret = '$(function(){' . $ret . '});';
			if($this->script_tag) $ret = '<script>' . $ret . '</script>';
			if($this->auto_echo) echo $ret; else return $ret;
		}

		public function highcharts($css_selector,$chart_type,$data,$title='',$thisval_prefix_on_tooltip='تعداد',$show_all_in_tooltip=true,$shared=false){
			$ret = '';
			$all_in_tooltip = $show_all_in_tooltip ? ' <br/>کل : <b>{point.total}</b>' : ''; 
			switch($chart_type){
				case 'pie':
					$type = 'pie';
					$sp = '';
					$js_data = '';
					foreach($data as $key=>$val){
						$js_data.= "$sp ['$key',".getor($val,'0').']';
						$sp=',';
					}
					$ret .= "
						$('$css_selector').highcharts({
							chart: {
								plotBackgroundColor: null,
								plotBorderWidth: null,
								plotShadow: false
							},
							title: {
								text: '$title'
							},
							tooltip: {
								pointFormat: '$thisval_prefix_on_tooltip : <b>{point.y}</b> ({point.percentage:.1f} درصد) $all_in_tooltip'
							},
							plotOptions: {
								pie: {
									allowPointSelect: true,
									cursor: 'pointer',
									dataLabels: {
										enabled: false
									},
									showInLegend: true
								}
							},
							series: [{
								type: '$type',
								data: [$js_data]
							}],
							credits: {
								enabled: false
							}
						});
					";
					break;
				case 'bar':
				case 'column':
				case 'stackedbar':
				case 'stackedcolumn':
				case 'spline':
				case 'areaspline':
					$type= ($chart_type=='bar'||$chart_type=='stackedbar')?
								('bar')
							:(
							($chart_type=='column'||$chart_type=='stackedcolumn')?
								('column')
							:(
							($chart_type=='spline')?
								('spline')
							:(
								$chart_type
							)));
					if($chart_type=='stackedbar' || $chart_type=='stackedcolumn'){
						$plotopt = 'series: {
										stacking: \'normal\'
									}';
					}
					elseif($chart_type=='spline' || $chart_type=='areaspline'){
						$plotopt = "
							$chart_type: {
								lineWidth: 2,
								states: {
									hover: {
										lineWidth: 3
									}
								},
								marker: {
									enabled: false
								}
							}
						";
					}
					else{
						$plotopt = 'bar: {
										dataLabels: {
											enabled: true
										}
									}';
					}
					if($shared)
						$tooltip = "pointFormat: '$thisval_prefix_on_tooltip : <b>{point.y}</b> $all_in_tooltip'";
					else
						$tooltip = 'shared:true,crosshairs: true';
					$height = 'null';
					if($chart_type=='bar' || $chart_type=='stackedbar'){
						$height = count($data) * 30 + 120;
					}
					$x_label=null;
					if($type=='column'||$type=='spline'||$type=='areaspline'){
							$all_x = count($data);
							$step = ceil( $all_x / 30 );
							$max =0;
							foreach($data as $key=>$val){
								if(strlen($key)>$max) $max = strlen($key);
							}
							if($max>5){
								$r = 'rotation:-90 ,';
							}else{
								$r='';
							}
							$x_label ="
								labels:{
								   $r
								   step: $step
								}";
					}
					$sp_x = '';
					$sp_d = '';
					$xAxis = '';
					$series = '';
					$series_t = array();
					foreach($data as $key=>$val){
						$xAxis.= "$sp_x ' $key '";
						$sp_x=',';
						foreach($val as $key_=>$val_){
							$series_t[$key_][] = $val_;
						}
					}
					$sp = '';
					foreach($series_t as $key=>$val){
						$vali = '';
						$sp_d = '';
						foreach($val as $val_){
							$vali.= $sp_d.getor($val_,'0');
							$sp_d=',';
						}
						$series.= "$sp{name:' $key ',data:[$vali]}\n";
						$sp=',';
					}
					//$series.= ',marker:{enabled:false}';
					$ret .= "
						$('$css_selector').highcharts({
							chart: {
								type: '$type',
								height: $height
							},
							title: {
								text: '$title'
							},
							xAxis: {
								categories: [$xAxis],
								$x_label
							},
							yAxis: {
								min: 0,
								title: {
									text: ''
								}
							},
							tooltip: {
								$tooltip
							},
							legend: {
								reversed: true
							},
							plotOptions: {
								$plotopt
							},
							series: [$series],
							credits: {
								enabled: false
							}
						});
					";
					break;
			}
			if($this->jquery_function) $ret = '$(function(){' . $ret . '});';
			if($this->script_tag) $ret = '<script>' . $ret . '</script>';
			if($this->auto_echo) echo $ret; else return $ret;
		}
	}
	
	class nai_validation{
		public function pattern($pattern_name,$min=1,$max='',$js_php_html='html'){
			$ret = '';
			$len = '{'.(getor($min)?$min:'1').','.(getor($max)?$max:'').'}';
			switch($pattern_name){
				case 'farsi':
					$ret = '[پچجحخهعغفقثصضشسیبلاتنمکگوئدذرزطظژؤآإأءًٌٍَُِّ\s]'.$len;
					break;
				case 'english':
					$ret = '[\w\s]'.$len;
					break;
				case 'addi':
					$ret = '[پچجحخهعغفقثصضشسیبلاتنمکگوئدذرزطظژؤآإأءًٌٍَُِّ:\s\w\d]'.$len;
					break;
				case 'email':
					$ret = '([\w\.]+)([@])([\w]+)([\.])([\w\.^\d]+)';
					break;
				case 'username':
					$ret = '[\w\.]'.$len;
					break;
				case 'number':
					$ret = '[\d]'.$len;
					break;
				case 'time':
					$ret = '([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]'.$len;
					break;
				case 'timenosec':
					$ret = '([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]'.$len;
					break;
				case 'counttime':
					$ret = '([\d][\d]):[0-5][0-9]:[0-5][0-9]'.$len;
					break;
				case 'counttimenosec':
					$ret = '([\d][\d]):[0-5][0-9]'.$len;
					break;
				case 'ip':
					$ret = '(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])';
					break;
					
				default:
					$ret = '.'.$len;
					break;
			}
			if($js_php_html == 'php') $ret = '/^' . $ret . '$/';
			//if($js_php_html == 'js') $ret = str_replace ( '\\' , '\\\\' , $ret );
			return $ret;
		}
		public function match($text,$pattern_name,$min=0,$max=''){
			return preg_match($this->pattern($pattern_name,$min,$max,'php'), $text);
		}
	}

	class nai_zdate{
		public function pdate_to_timestamp($p_date,$delimiter = '/'){
			list($year,$month,$day) 	= explode($delimiter, $p_date);
			return jmktime(0,0,0,(float)trim($month),(float)trim($day),(float)trim($year));
		}
		public function date_to_timestamp($date,$delimiter = '/'){
			list($year,$month,$day) 	= explode($delimiter, $date);
			return mktime(0,0,0,(float)trim($month),(float)trim($day),(float)trim($year));
		}
		
		public function pdate_to_mysqldate($p_date,$delimiter = '/',$max = false,$milisecond = false,$havetime=true){
			$timestamp = $this->pdate_to_timestamp($p_date,$delimiter);
			return date('Y-m-d'. (($havetime)?(' '. ($max==true?'23:59:59':'00:00:00').($milisecond?':00.000000':'')):('')),$timestamp);
		}
		public function timestamp_to_mysqldate($timestamp){
			if(!$timestamp) $timestamp = time();
			return date('Y-m-d H:i:s',$timestamp);
		}
		public function timestamp_to_mysqldateonly($timestamp){
			if(!$timestamp) $timestamp = time();
			return date('Y-m-d',$timestamp);
		}
		public function pdate_to_mysqldateonly($p_date,$delimiter = '/'){
			$timestamp = $this->pdate_to_timestamp($p_date,$delimiter);
			return date('Y-m-d',$timestamp);
		}
		
		public function mysqldateonly_to_pdate($mysql_date,$delimiter = '-'){
			$timestamp = $this->mysqldateonly_to_timestamp($mysql_date,$delimiter);
			return jdate('Y/m/d',$timestamp);
		}
		public function timestamp_to_pdate($timestamp){
			if(!$timestamp) $timestamp = time();
			return jdate('Y/m/d',$timestamp);
		}
		
		public function mysqldateonly_to_timestamp($mysqldate,$datedelimiter = '-'){
			list($year,$month,$day) 	= explode($datedelimiter, $mysqldate);
			return mktime(0,0,0,(float)trim($month),(float)trim($day),(float)trim($year));
		}
		public function mysqldate_to_timestamp($mysqldate,$datedelimiter = '-',$timedelimiter = ':',$milisecend = false){
			//2013-07-23 00:29:00
			//2014-03-16 16:44:16
			list($date,$time) =  explode(' ', $mysqldate);
			list($year,$month,$day) 	= explode($datedelimiter, $date);
			if($milisecend){
				list($timeh,$timem) = explode('.', $time);
				list($hour,$minute,$second) 	= explode($timedelimiter, $timeh);
			}
			else{
				list($hour,$minute,$second) 	= explode($timedelimiter, $time);
			}
			return mktime((float)trim($hour),(float)trim($minute),(float)trim($second),(float)trim($month),(float)trim($day),(float)trim($year));
			
		}
		
		
		public function time_to_sec($time,$timedelimiter=':',$hassec=true){
			if($hassec){
				list($hour,$minute,$second) 	= explode($timedelimiter, $time);
				return (int)$second + ((int)$minute * 60) + ((int)$hour * 3600);
			}
			else{
				list($hour,$minute) 	= explode($timedelimiter, $time);
				return ((int)$minute * 60) + ((int)$hour * 3600);
			}
		}
		
		public function sec_to_time($sec_,$timedelimiter=':'){
			$allsec = floor($sec_);
			$hor = floor($allsec/3600); $allsec = $allsec%3600;
			$min = floor($allsec/60); $allsec = $allsec%60;
			$sec = $allsec;
			return minlength($hor,2,true,'0').$timedelimiter.minlength($min,2,true,'0').$timedelimiter.minlength($sec,2,true,'0');
		}
		
	}
	
	$zd = new nai_zdate();
	$vl = new nai_validation();
	$js = new nai_javascript();

?>