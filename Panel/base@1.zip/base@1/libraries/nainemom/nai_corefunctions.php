<?php
	include_once('jdf.php');
	include_once('nai_myclass.php');
	include_once('nai_require.php');
	
	
	function include_plugin($plugin){
		$ret = null;
		switch($plugin){
			case 'highcharts':case 'highchart':
				$ret .= '<script src="assets/nai_plugin/highcharts/highcharts.js"></script>';
				$ret .= '<script src="assets/nai_plugin/highcharts/highcharts-more.js"></script>';
				$ret .= '<script src="assets/nai_plugin/highcharts/highcharts-3d.js"></script>';
				$ret .= '<script src="assets/nai_plugin/highcharts/theme.js"></script>';
				break;
			case 'jqgrid': case 'jquerygrid':
				$ret .= '<link rel="stylesheet" href="assets/nai_plugin/jqGrid/css/ui.jqgrid.css" />';
				$ret .= '<link rel="stylesheet" href="assets/nai_plugin/jqGrid/css/jquery-ui.css" />';
				$ret .= '<script src="assets/nai_plugin/jqGrid/js/jquery.jqGrid.src.js"></script>';
				$ret .= '<script src="assets/nai_plugin/jqGrid/js/i18n/grid.locale-fa.js"></script>';
				break;
		}
		echo $ret;
	}

	function nai_myampusers_getuser($user_xname){
		global $nai_db;
		$user_x = $nai_db->querytoarray("SELECT * FROM ampusers WHERE username = '$user_xname';");
		return $user_x[0];
	}
	function nai_myampusers_getusergroups($user_x_name){
		global $nai_db;
		$ret = array();
		$user_x = nai_myampusers_getuser($user_x_name);
		$user_x_id = $user_x['id'];
		$groups = $nai_db->querytoarray("SELECT group_id FROM group_members WHERE user_id = '$user_x_id';");
		foreach($groups as $val){
			$t = $nai_db->querytoarray("SELECT * FROM `group` WHERE id = '$val[group_id]';");
			$ret[] = $t[0];
		}
		return $ret;
	}
	function nai_myampusers_is_admin($user_xname){
		global $nai_db;
		if( $user_xname == 'ERROR' ) return false;
		$user_x = nai_myampusers_getuser($user_xname);
		$user_x_id = $user_x['id'];
		if(!$user_x_id) return true;
		return $user_x_id=='1'?true:false;
	}
	function nai_myampusers_is_admin_byid($user_x_id){
		return $user_x_id=='1'?true:false;
	}
	
	function nai_is_module_installed($module_name){
		global $nai_db;
		$module = $nai_db->querytoarray("SELECT `modulename` FROM `modules` WHERE `modulename` = '$module_name' AND `enabled` = 1;");
		return $module[0]['modulename']!=''?true:false;
	}
	function nai_is_module_disabled($module_name){
		global $nai_db;
		$module = $nai_db->querytoarray("SELECT `enabled` FROM `modules` WHERE `modulename` = '$module_name';");
		return $module[0]['enabled']=='1'?false:true;
	}
	
	function nai_module_access_options($module_name){
		global $nai_db,$username;
		if( ! nai_is_module_installed('groups') ||  nai_myampusers_is_admin($username) ) return true;
		//$display = $display=='index'?'dashboard':$display;
		//$module = nai_mymodulesadmin_getmodule($display);
		$user_xgroups = nai_myampusers_getusergroups($username);
		$permissions_to_this_page = array();

		foreach($user_xgroups as $group){
			$per_ = $nai_db->querytoarray("SELECT * FROM `permission` WHERE group_id = '$group[id]' AND `name` = '$module_name' AND web_resource = TRUE;");
			foreach($per_ as $perr){
				if( $perr['in_permission'] == '' ){
					return true;
				}
				else{
					if( ! in_array( $perr['in_permission'] , $permissions_to_this_page))
						$permissions_to_this_page[] = $perr['in_permission'];
				}
			}
		}
		return $permissions_to_this_page;
	}
	function nai_check_this_user_can_access_to_this_module($user_xname,$display,$fordeveloper=false){
		global $nai_db;//,$module;
		
		if( ! nai_is_module_installed('groups') ) return true;
		$user_x = nai_myampusers_getuser($user_xname);
		
		if( $user_x['id'] == 1 ) return true;
		if( $display == 'modules' && $user_x['id'] != 1 ) return false; // age admin bashe k tu khate balayi true mishe, pas inja bayad false bashe
		//$display = $display=='index'?'dashboard':$display;
		$thismdl = nai_mymodulesadmin_getmodule($display);
		if( $thismdl == null ) return null;
		//$module = nai_mymodulesadmin_getmodule($display);
		$user_xgroups = nai_myampusers_getusergroups($user_xname);
		$permissions_to_this_page = array();
		
		foreach($user_xgroups as $group){
			$per_ = $nai_db->querytoarray("SELECT * FROM `permission` WHERE group_id = '$group[id]' AND `name` = '$display' AND web_resource = TRUE;");
			foreach($per_ as $perr){
				if( $perr['in_permission'] == '' ){
					return true;
				}
				else{
					if( ! in_array( $perr['in_permission'] , $permissions_to_this_page))
						$permissions_to_this_page[] = $perr['in_permission'];
				}
			}
		}
		
		//print_r( $thismdl );

		
		if(count($permissions_to_this_page)>0){
			if($thismdl['ifaccessloadanyway'] == 'true') return true;
			$ret = array();
			foreach($permissions_to_this_page as $perrr){
				$expp = explode('&',$perrr);
				$n = true;
				foreach($expp as $exppp){
					$exp = explode('=',$exppp);
					$key = $exp[0];
					$value = $exp[1];
					if( $value != getor( $_REQUEST[$key] ) ) $n = false;
				}
				if($n==true) return true;
				if( $fordeveloper )
					$ret[] = $perrr;
				else
					$ret[] = "<a href=\"config.php?display=$display&$perrr\"> $perrr </a>";
			}

			
			return $ret;
		}
		else{
			return false;
		}
	}

	function nai_mymodulesadmin_getmodules_from_db($justenabled=true){
		global $nai_db;
		if($justenabled) $where = 'enabled = 1'; else $where = 'TRUE';
		$modules = $nai_db->querytoarray("SELECT * FROM modules WHERE $where;");
		return $modules; 
		
		
	}
	function nai_mymodulesadmin_getmodules_to_array($retcat = false){
		$dir__ = $amp_conf['AMPWEBROOT'] . '/admin';
		$ret = array();
		$modules = nai_mymodulesadmin_getmodules_from_db();
		$i=0;
		$all_category = array();
		$all_subcategory = array();
		foreach($modules as $module){
				$module_directory = '/var/www/html' . $dir__ . '/modules/'.$module['modulename'].'/';
				$module_xml_file_address = file_get_contents( $module_directory.'/'.'module.xml');
				$xml = XMLtoArray($module_xml_file_address);
				
				$n = 0;
				foreach($xml['MODULE']['MENUITEMS'] as $menuitem => $etelaat){
					$ret[$i]['directory'] = $module_directory;
					$ret[$i]['xml']['content'] = $xml;
					$ret[$i]['xml']['directory'] = $module_xml_file_address;

					if( isset($xml['MODULE']['MENUITEMS'][$menuitem]['CATEGORY']) && strlen($xml['MODULE']['MENUITEMS'][$menuitem]['SUBCATEGORY']) > 1)
						$ret[$i]['category'] = $xml['MODULE']['MENUITEMS'][$menuitem]['CATEGORY'];
					else
						$ret[$i]['category'] = $xml['MODULE']['CATEGORY'];
						
					if( isset($xml['MODULE']['MENUITEMS'][$menuitem]['SUBCATEGORY']) && strlen($xml['MODULE']['MENUITEMS'][$menuitem]['SUBCATEGORY']) > 1)
						$ret[$i]['subcategory'] = $xml['MODULE']['MENUITEMS'][$menuitem]['SUBCATEGORY'];
					else
						$ret[$i]['subcategory'] = $xml['MODULE']['SUBCATEGORY'];

					$ret[$i]['rel'] =  getor ( $xml['MODULE']['REL'] , $xml['MODULE']['REL']);
					$ret[$i]['name'] = strtolower($menuitem);
					$ret[$i]['title'] = is_array ( $etelaat ) ? $etelaat['content'] : $etelaat ;
					$ret[$i]['href'] = 'config.php?display=' . strtolower($menuitem);
					$ret[$i]['ifaccessloadanyway'] = getor ( $xml['MODULE']['IFACCESSLOADANYWAY'] , $xml['MODULE']['IFACCESSLOADANYWAY']);
					
					$all_category[$ret[$i]['category']][$ret[$i]['subcategory']][] = $ret[$i];
					$i++;
				}
				
		}
		//print_r($all_category);

		
		if($retcat) return $all_category; else return $ret;
	}
	function nai_mymodulesadmin_getmodule($module_name){
		$dir__ = $amp_conf['AMPWEBROOT'] . '/admin';
		$ret = array();
		$modules = nai_mymodulesadmin_getmodules_from_db();
		foreach($modules as $module){
				$module_directory = '/var/www/html' . $dir__ . '/modules/'.$module['modulename'].'/';
				$module_xml_file_address = file_get_contents( $module_directory.'/'.'module.xml');
				$xml = XMLtoArray($module_xml_file_address);
				
				$n = 0;
				foreach($xml['MODULE']['MENUITEMS'] as $menuitem => $etelaat){
					if(strtolower($menuitem) == strtolower($module_name)){
						$ret['directory'] = $module_directory;
						$ret['xml']['content'] = $xml;
						$ret['xml']['directory'] = $module_xml_file_address;
						$ret['category'] = getor ( $xml['MODULE']['CATEGORY'] , $xml['MODULE']['CATEGORY']);
						$ret['subcategory'] = getor ( $xml['MODULE']['SUBCATEGORY'] , $xml['MODULE']['SUBCATEGORY']);
						$ret['rel'] =  getor ( $xml['MODULE']['REL'] , $xml['MODULE']['REL']);
						$ret['name'] = strtolower($menuitem);
						$ret['rawname'] = strtolower($xml['MODULE']['RAWNAME']);
						$ret['title'] = is_array ( $etelaat ) ? $etelaat['content'] : $etelaat ;
						$ret['href'] = 'config.php?display=' . strtolower($menuitem);
						$ret['ifaccessloadanyway'] = getor ( $xml['MODULE']['IFACCESSLOADANYWAY'] , $xml['MODULE']['IFACCESSLOADANYWAY']);
						return $ret;
					}
				}
		}
		return null;
	}
	
	function nai_add_alert($text){
		global $alert_in_page;
		$text = str_replace('"','',$text);
		$text = str_replace("'",'',$text);
		$text = str_replace("\n",'<br>',$text);




		$alert_in_page.= tag('tr','',
									tag('td','class=\'closebtn\'', tag('span','class=\'icon icon-times s18\'') ) .
									tag('td','class=\'text\'',$text)
			);
			
		//$alert_in_page.= $text.'\n';
	}
	function nai_get_alerts(){
		global $alert_in_page;
		return $alert_in_page;
	}
	
	
	function nai_basemodules_includes_panel(){
		global $username;
		$nai_modules = nai_mymodulesadmin_getmodules_from_db();
		
		foreach( $nai_modules as $nai_module ) {
			$nai_module_ = nai_mymodulesadmin_getmodule($nai_module['modulename']);
			if( nai_check_this_user_can_access_to_this_module($username,$nai_module['modulename']) === false )
				continue;
			
			$nai_basejs = $nai_module_['xml']['content']['MODULE']['BASEPANEL']['JS'];
			if( is_array($nai_basejs) )
				foreach ( $nai_basejs as $nai_jsfile )
					echo tag('script','src="modules/'.$nai_module['modulename'].'/'.$nai_jsfile.'"','');
			elseif( $nai_basejs )
				echo tag('script','src="modules/'.$nai_module['modulename'].'/'.$nai_basejs.'"','');
				
			$nai_basecss = $nai_module_['xml']['content']['MODULE']['BASEPANEL']['CSS'];
			if( is_array($nai_basecss) )
				foreach ( $nai_basecss as $nai_cssfile )
					echo tag('link','href="modules/'.$nai_module['modulename'].'/'.$nai_cssfile.'" rel="stylesheet" type="text/css"','');
			elseif( $nai_basecss )
				echo tag('link','href="modules/'.$nai_module['modulename'].'/'.$nai_basecss.'" rel="stylesheet" type="text/css"','');

				
			$nai_basephp = $nai_module_['xml']['content']['MODULE']['BASEPANEL']['PHP'];
			if( is_array($nai_basephp) )
				foreach ( $nai_basephp as $nai_phpfile )
					include 'modules/'.$nai_module['modulename'].'/'.$nai_phpfile;
			elseif( $nai_basephp )
				include 'modules/'.$nai_module['modulename'].'/'.$nai_basephp;
		}
	}
	
	function nai_basemodules_includes_header(){
		global $username;
		$nai_modules = nai_mymodulesadmin_getmodules_from_db();
		
		foreach( $nai_modules as $nai_module ) {
			$nai_module_ = nai_mymodulesadmin_getmodule($nai_module['modulename']);
			if( nai_check_this_user_can_access_to_this_module($username,$nai_module['modulename']) === false )
				continue;
			
			$nai_basejs = $nai_module_['xml']['content']['MODULE']['BASEHEADER']['JS'];
			if( is_array($nai_basejs) )
				foreach ( $nai_basejs as $nai_jsfile )
					echo tag('script','src="modules/'.$nai_module['modulename'].'/'.$nai_jsfile.'"','');
			elseif( $nai_basejs )
				echo tag('script','src="modules/'.$nai_module['modulename'].'/'.$nai_basejs.'"','');
				
			$nai_basecss = $nai_module_['xml']['content']['MODULE']['BASEHEADER']['CSS'];
			if( is_array($nai_basecss) )
				foreach ( $nai_basecss as $nai_cssfile )
					echo tag('link','href="modules/'.$nai_module['modulename'].'/'.$nai_cssfile.'" rel="stylesheet" type="text/css"','');
			elseif( $nai_basecss )
				echo tag('link','href="modules/'.$nai_module['modulename'].'/'.$nai_basecss.'" rel="stylesheet" type="text/css"','');

				
			$nai_basephp = $nai_module_['xml']['content']['MODULE']['BASEHEADER']['PHP'];
			if( is_array($nai_basephp) )
				foreach ( $nai_basephp as $nai_phpfile )
					include 'modules/'.$nai_module['modulename'].'/'.$nai_phpfile;
			elseif( $nai_basephp )
				include 'modules/'.$nai_module['modulename'].'/'.$nai_basephp;
		}
	}
	
	
	function nai_log($x){
		$content = null;
		$fAddress = 'nailog.txt';
		if( file_exists($fAddress) ){
			$rLnk = fopen($fAddress, 'r') or die('1');
			$content = fread($rLnk,filesize($fAddress));
			fclose($rLnk);
		}
		$wLnk = fopen($fAddress, 'w') or die('2');
		
		//$backtrace = debug_backtrace();
		
		$log = date('Y-m-d G:i:s') . ": $x \n----------------------------------------\n";
		fwrite($wLnk, $log );
		fwrite($wLnk, $content );
		
		
		fclose($wLnk);
	}

?>