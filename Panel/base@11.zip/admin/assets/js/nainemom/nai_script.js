$(document).ready(function() {
	nodeSocket.on('hi', function() {
		alert('hi');
	});
	//$('#nai_content h2').addClass('ready');
	

	
	$rnav = $('.rnav').eq(0);
	if ($rnav.html()) {
		$('.rnav a.selected,.rnav a.current,.rnav a#current').parent('li').addClass('selected');
		$rnav.after('<div id="showhidemavared"><span class="icon icon-cabinet s28 light"></span></div>');
		$showhidemavared = $('#showhidemavared');
		$rnav.addClass('collapse');
		$showhidemavared.addClass('collapse');
		$nai_masir = $('#nai_masir');
		opened = false;
		$showhidemavared.click(function(e) {
			e.stopPropagation();
			if (opened) {
				$showhidemavared.removeClass('expand').addClass('collapse');
				$rnav.removeClass('expand').addClass('collapse');
			} else {
				$showhidemavared.removeClass('collapse').addClass('expand');
				$rnav.removeClass('collapse').addClass('expand');
			}
			opened = !opened;
		});
		$rnav.click(function(e) {
			e.stopPropagation();
		});
		$('html').click(function() {
			if (opened) {
				$showhidemavared.removeClass('expand').addClass('collapse');
				$rnav.removeClass('expand').addClass('collapse');
				opened = !opened;
			}
		});
		$(window).scroll(function() {
			var scrltop = $(window).scrollTop();
			var x = (scrltop < 60) ? (60 - scrltop) : (0);
			$showhidemavared.css('top', x + 'px');
			$rnav.css('top', x + 'px');
		}).scroll();
		var $searchLi = $('<li>').addClass('searchitems').prependTo($rnav.children('ul').eq(0));
		var $searchInput = $('<input>').attr('type', 'text').attr('placeholder', 'جست و جو در آیتم ها').attr('id', 'searchrnav').appendTo($searchLi);
		var $searchIcon = $('<span>').addClass('icon').addClass('icon-magnifying-glass').addClass('dark').addClass('s18').addClass('search_icon').appendTo($searchLi);
		var $allItems = $rnav.children('ul').children('li').not(':first-child');
		for (i = 0; i < $allItems.length; i++) {
			if (typeof $allItems.eq(i).attr('data-search') === 'undefined') {
				var dataSearch = ($allItems.eq(i).text()).toLowerCase();
				$allItems.eq(i).attr('data-search', dataSearch);
			}
		}
		$($searchInput).keyup(function(e) {
			var key = ($(this).val()).toLowerCase();
			var $items = $(this).parent('li').parent('ul').children('li:not(:first-child)');
			$('#itemresult').remove();
			if (key != '') {
				var $founded = $(this).parent('li').parent('ul').children("li[data-search*='" + key + "']");
				var $ul = $('<ul>').attr('id', 'itemresult').appendTo($rnav);
				for (i = 0; i < $founded.length; i++) {
					var itemAddress = $founded.eq(i).children('a').eq(0).attr('href');
					var itemText = $founded.eq(i).text();
					var $li = $('<li>').addClass('moduleresult').appendTo($ul);
					var $a = $('<a>').attr('href', itemAddress).text(itemText).appendTo($li);
				}
				$items.hide();
			} else {
				$items.fadeTo('slow', 1);
			}
		});
	}
	var $naiSidebar = $('#nai_sidebar');
	var $naiSidebarAllMenu = $('#nai_sidebar .allmenu');
	var $zirSubCategorys = $('#nai_sidebar .zirsubcategory');
	var $zirCategorys = $('#nai_sidebar .zircategory');
	var $categorys = $('#nai_sidebar li.category');
	var $selectedModule = $('#nai_sidebar .selected');
	var $headersCategory = $('#nai_sidebar li.category > .header');
	var $headersSubCategory = $('#nai_sidebar li.subcategory > .header');
	var $modules = $('#nai_sidebar').find('.module');
	var $emptyZirSubCategory = $('#nai_sidebar .zirsubcategory:empty');
	var moduleItemHeight = 26;
	var $modiriatCategory = $headersCategory.children('.text:contains("مدیریت")').parent('.header').parent('.category');
	var $nezaaratCategory = $headersCategory.children('.text:contains("نظارت")').parent('.header').parent('.category');
	var $gozareshCategory = $headersCategory.children('.text:contains("گزارش")').parent('.header').parent('.category');
	var $operatorCategory = $headersCategory.children('.text:contains("اپراتور")').parent('.header').parent('.category');
	$modiriatCategory.appendTo($naiSidebarAllMenu);
	$nezaaratCategory.appendTo($naiSidebarAllMenu);
	$gozareshCategory.appendTo($naiSidebarAllMenu);
	$operatorCategory.appendTo($naiSidebarAllMenu);
	$emptyZirSubCategory.hide().prev('.header').remove();
	for (i = 0; i < $categorys.length; i++) {
		var $curCategory = $categorys.eq(i);
		var $curCategoryModules = $curCategory.find('.module');
		if ($curCategoryModules.length == 0)
			$curCategory.remove();
	}
	for (i = 0; i < $zirSubCategorys.length; i++) {
		var $curZirSubCategory = $zirSubCategorys.eq(i);
		var curZirSubCategoryModulesCount = parseInt($curZirSubCategory.find('a:last-child').data('item-number'));
		var curZirSubCategoryHeight = curZirSubCategoryModulesCount * moduleItemHeight;
		/* $curZirSubCategory.css('height', curZirSubCategoryHeight + 'px'); */
	}
	$zirSubCategorys.removeClass('expand').addClass('collapse');
	$zirCategorys.removeClass('expand').addClass('collapse');
	$selectedModule.parents('.zircategory').eq(0).removeClass('collapse').addClass('expand');
	$selectedModule.parents('.zirsubcategory').eq(0).removeClass('collapse').addClass('expand');
	$selectedModule.parents('li.category').addClass('selected');
	$selectedModule.parents('.zirsubcategory').eq(0).removeClass('collapse').addClass('expand');
	$headersCategory.click(function() {
		var $nextZirCategory = $(this).next('.zircategory').eq(0);
		var $parentCategory = $(this).parent('li.category');
		if ($nextZirCategory.hasClass('collapse')) {
			$categorys.not($parentCategory).removeClass('selected');
			$zirCategorys.not($nextZirCategory).removeClass('expand').addClass('collapse');
			$zirSubCategorys.removeClass('expand').addClass('collapse');
			$parentCategory.addClass('selected');
			$nextZirCategory.removeClass('collapse').addClass('expand');
		} else {
			$categorys.removeClass('selected');
			$zirCategorys.removeClass('expand').addClass('collapse');
			$zirSubCategorys.removeClass('expand').addClass('collapse');
		}
	});
	$headersSubCategory.click(function() {
		var $nextZirSubCategory = $(this).next('.zirsubcategory');
		if ($nextZirSubCategory.hasClass('collapse')) {
			$zirSubCategorys.not($nextZirSubCategory).removeClass('expand').addClass('collapse');
			$nextZirSubCategory.removeClass('collapse').addClass('expand');
		} else {
			$nextZirSubCategory.removeClass('expand').addClass('collapse');
		}
	});
	$('#nai_sidebar .search input').keyup(function(e) {
		val = ($(this).val()).toLowerCase();
		$('#nai_sidebar .result').remove();
		results = '<ul class="result">';
		$('#nai_sidebar .result').hide(0);
		if (val == '') {
			$('#nai_sidebar .allmenu').slideDown('1.2');
		} else {
			$('#nai_sidebar .allmenu').slideUp('1.2');
			$founded = $('#nai_sidebar li.module[title*="' + val + '"]');
			if ($founded.length == 0) {
				results += '<li class="moduleresult notfound"> چیزی تحت عنوان "' + val + '" پیدا نشد.</li>';
			} else {
				for (i = 0; i < $founded.length; i++) {
					var catName = $founded.eq(i).parents('li').eq(1).children('.header').eq(0).text();
					results += '<a href="' + $founded.eq(i).parents('a').eq(0).attr('href') + '"><li class="moduleresult '+ $founded.eq(i).attr('class') +'">' + '<span class="category">' + catName + '</span>' + ' <span class="icon s16 icon-chevron-left category"></span> ' + $founded.eq(i).text() + '</li></a>';
				}
			}
			results += '</ul>';
			$('#nai_sidebar').append(results);
		}
	});
	$('#notif_count').on('sub', function() {
		var nai_NotifCount = parseInt($(this).attr('data-notifcount'));
		nai_NotifCount--;
		$(this).attr('data-notifcount', nai_NotifCount).text(nai_NotifCount);
		if (nai_NotifCount < 1) {
			$(this).hide();
			$('#no_notif').removeClass('nai_hide');
		}
	});
	inputwidth = $('<input/>', {
		id: 'nai_temorary_text_box',
		type: 'text'
	}).appendTo('body').outerWidth();
	$('#nai_temorary_text_box').remove();
	$('input[type=datepicker]').persianDatepicker({
		selectedBefore: true,
		persianNumbers: false,
		cellWidth: 28,
		cellHeight: 28,
		fontSize: 13,
	}).attr('readonly', 'readonly').css('min-width', '200px');
	$("input[type=text].counttime, input[type=text].time").mask('99:99:99').attr('pattern', '([\\d][\\d]):[0-5][0-9]:[0-5][0-9]{1,}');
	$("select.chosen").chosen({
		disable_search_threshold: 10
	});
	$('input[type=checkbox].onoff').onoff();
	$(".tooltip_tipper").each(function(key, value) {
		$(value).tipper({
			direction: $(value).data('direction') ? $(value).data('direction') : 'left'
		});
	});
	$('[data-mod="advanced-settings-button"]').click(function() {
		var $elem = $('[data-mod="advanced-settings"]');
		$elem.fadeToggle('slow');
		$(this).toggleClass('selected');
		if ($(this).hasClass('selected')) {
			var x = $elem.offset().top;
			$('html, body').animate({
				scrollTop: x
			}, 1000);
		}
	});
	$('#nai_footer').click(function() {
		if ($(window).scrollTop() + $(window).height() == $(document).height()) {
			$('.show_query').fadeToggle('slow');
		}
	});
	$(document).on('click', '#alert_in_page .closebtn', function() {
		$(this).parent('tr').fadeTo('slow', 0, function() {
			$(this).remove();
		});
	});
	$('input').attr('autocomplete', 'off');
	$('form').attr('autocomplete', 'off');
	$('.chzn-container .search-field input').attr('placeholder', '+');
	var $inputWithSize = $('input[size]');
	for (i = 0; i < $inputWithSize.length; i++)
		$inputWithSize.eq(i).attr('pattern', '.{0,' + (parseInt($inputWithSize.eq(i).attr('size')) + 1) + '}').removeAttr('size');

	function isRtl(str) {
		if (str.charCodeAt(0) > 255) {
			return true;
		}
		return false;
	}
	$(document).on('keyup', 'input[type=text]', function(e) {
		if (isRtl($(this).val())) {
			$(this).css('direction', 'rtl');
		} else {
			$(this).css('direction', 'ltr');
		}
	});
	$('[data-do=browse]').click(function() {
		var $thiss = $(this);
		$('#' + $thiss.data('elem')).click();
		$('#' + $thiss.data('elem')).change(function() {
			$thiss.text($(this).val())
		});
	});
	$("[required]").on("invalid", function(e) {
		if (!$(this)[0].validity.valid && $(this)[0].value == '') {
			$(this)[0].setCustomValidity("مقدار این فیلد نباید خالی باشد");
		} else if (!$(this)[0].validity.valid) {
			$(this)[0].setCustomValidity("مقدار وارد شده صحیح نیست");
		}
	});
	$("[required]").on("change keyup", function() {
		$(this)[0].setCustomValidity('');
	});
});