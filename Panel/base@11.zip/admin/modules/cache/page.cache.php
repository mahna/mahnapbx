<?php
	global $__cache_settings,$__cache_settings_string_path,$__cache_global, $js;
	$action = getor($_REQUEST['action'],'none');

	switch($action){
		case 'submit':
			$__cache_settings['enable'] = (bool)getor( $_POST['checkbox-enable'] );
			$__cache_settings['period'] = (integer)getor( $_POST['select-period'] );

			$iswrite = file_put_contents( $__cache_settings_string_path, json_encode( $__cache_settings ) );
			if( $iswrite  )
				nai_add_alert('تنظیمات با موفقیت ذخیره شد.');
			else
				nai_add_alert('ذخیره تنظیمات با مشکل مواجه شد.');
			
			break;
		case 'reload':
			$__cache_global->publicReload();
			break;
	}
?>



<h2>حافظه نهان</h2>


<form method="post">
	<table class="nai_table conf_table">
		<tr class="title">
			<td colspan="2">
				<h4> تنظیمات عمومی </h4> <hr/>
			</td>
		</tr>
		<tr>
			<td>
				فعال
			</td>
			<td>
				<input type="checkbox" name="checkbox-enable" class="onoff" <?php echo $__cache_settings['enable']?'checked':''; ?> >
			</td>
		</tr>
		<tr>
			<td>
				فاصله هر به‌روزرسانی
			</td>
			<td>
				<select name="select-period">
					<option <?php echo $__cache_settings['period']=='15'?'selected':''; ?> value="15">15 دقیقه</option>
					<option <?php echo $__cache_settings['period']=='30'?'selected':''; ?> value="30">30 دقیقه</option>
					<option <?php echo $__cache_settings['period']=='60'?'selected':''; ?> value="60">1 ساعت</option>
					<option <?php echo $__cache_settings['period']=='120'?'selected':''; ?> value="120">2 ساعت</option>
					<option <?php echo $__cache_settings['period']=='360'?'selected':''; ?> value="360">6 ساعت</option>
					<option <?php echo $__cache_settings['period']=='720'?'selected':''; ?> value="720">12 ساعت</option>
					<option <?php echo $__cache_settings['period']=='1440'?'selected':''; ?> value="1440">24 ساعت</option>
					<option <?php echo $__cache_settings['period']=='999999'?'selected':''; ?> value="999999">هرگز</option>
				</select>
			</td>
		</tr>

		<tr class="title">
			<td colspan="2">
				<button type="submit" name="action" value="submit"> ثبت </button> | 
				<button class="none" name="action" value="reload"> به‌روزرسانی حافظه‌ نهان </button>
			</td>
		</tr>
	</table>
</form>

<script>

	$(function(){

		<?php
		if($group !== null){
		?>
		<?php
		}
		?>
	});
</script>