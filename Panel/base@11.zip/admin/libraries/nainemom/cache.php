<?php
	$__cache_settings['enable'] = true;
	$__cache_settings['period'] = 360;
	$__cache_global = new Cache;
	if( $__cache_global->needReload() ){
		$__cache_global->reload();
	}
	class Cache{
		private $_functionName, $_argsString;
		private $_sessionLink;
		private $_my_public_reload_path;
		private $_can_cache = true;
		function __construct  ( $functionName=null, $args = array() ){
			global $nai_db,  $__cache_settings;
			if( !isset($_SESSION['AMP_user']) || !$__cache_settings['enable'] ) {
				$this->_can_cache = false;
				return false;
			}
			$this->_my_public_reload_path = session_save_path().'/'.$_SESSION['AMP_user']->username.'.reload' ;
			if( !$functionName ) return true; // now just lastReload, needReload and reload method available
			
			$this->_functionName = $functionName;
			$this->_argsString = crc32(implode( '-', $args ));
			
			$this->_sessionLink = &$_SESSION[ '__cache' ][ $this->_functionName ][ $this->_argsString ];
		}
		function exists( ){
			if( !$this->_can_cache ) return false;
			return isset( $this->_sessionLink );
		}
		
		function get( ){
			return $this->_sessionLink;
		}
		
		function put( $value ){
			return $this->_sessionLink = $value; 
		}
		
		function reload( ){
			// create my file and remove my cache
			if( !$this->_can_cache ) return false;
			fclose( fopen( $this->_my_public_reload_path ,'w') );
			$_SESSION[ '__cache' ] = null;
			$_SESSION[ '__cache_last_reload' ] = time();	
		}
		
		
		function publicReload($autorefresh=true){
			// all user check if her file dont exists, reload. and this function delete all user files
			if( !$this->_can_cache ) return false;
			array_map('unlink', glob( session_save_path().'/*.reload' ));
			if($autorefresh) header("Location: config.php");
			return true;
		}
		

		function needReload(){
			// check if my file dont exists or time of cache is expired, return true;
			if( !$this->_can_cache ) return false;
			global $__cache_settings;
			if( !file_exists( $this->_my_public_reload_path ) )
				return true;
			return ($this->lastReload() + ($__cache_settings['period'] * 60) < time());
		}
		
		
		function printt($fName=null){
			var_dump( $fName?$_SESSION[ '__cache' ][$fName]:$_SESSION[ '__cache' ] );
		}
		
		function lastReload(){
			return getor( $_SESSION[ '__cache_last_reload' ], 'ERROR!' );
			
		}

	}
?>