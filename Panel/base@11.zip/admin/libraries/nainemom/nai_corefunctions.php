<?php
	
	include_once('jdf.php');
	include_once('nai_myclass.php');
	include_once('nai_require.php');
	include_once( 'cache.php' );
	
	

	
	function include_plugin($plugin,$autoecho=true){
		if( !ncl() ) return false;
		switch($plugin){
			case 'highcharts':case 'highchart':
				include_js('assets/nai_plugin/highcharts/highcharts.js',$autoecho);
				include_js('assets/nai_plugin/highcharts/highcharts-more.js',$autoecho);
				include_js('assets/nai_plugin/highcharts/highcharts-3d.js',$autoecho);
				include_js('assets/nai_plugin/highcharts/theme.js',$autoecho);
				break;
			case 'jqgrid': case 'jquerygrid':
				include_css('assets/nai_plugin/jqGrid/css/ui.jqgrid.css',$autoecho);
				include_css('assets/nai_plugin/jqGrid/css/jquery-ui.css',$autoecho);
				include_js('assets/nai_plugin/jqGrid/js/jquery.jqGrid.src.js',$autoecho);
				include_js('assets/nai_plugin/jqGrid/js/i18n/grid.locale-fa.js',$autoecho);
				break;
			case 'vis':
				include_css('assets/nai_plugin/vis/vis.min.css',$autoecho);
				include_js('assets/nai_plugin/vis/vis.min.js',$autoecho);
				break;
			case 'jquery':
				include_js('assets/js/jquery-1.7.1.min.js',$autoecho);
				break;
			case 'jqueryui':
				include_css('assets/css/jquery-ui.css',$autoecho);
				include_js('assets/js/jquery-ui-1.8.9.min.js',$autoecho);
				break;
			case 'chosen':
				include_css('assets/nai_plugin/chosen/chosen.css',$autoecho);
				include_js('assets/nai_plugin/chosen/chosen.jquery.js',$autoecho);
				break;
			case 'socket.io':case 'socketio':
				include_js('assets/nai_plugin/socket.io-1.3.5.js',$autoecho);
				break;
			case 'persianDatepicker': case 'persiandatepicker':
				include_css('assets/nai_plugin/persianDatepicker/css/persianDatepicker-default.css',$autoecho);
				include_js('assets/nai_plugin/persianDatepicker/js/persianDatepicker.js',$autoecho);
				break;
			case 'tipper': case 'fstipper': case 'fs.tipper':
				include_css('assets/nai_plugin/tipper/jquery.fs.tipper.min.css',$autoecho);
				include_js('assets/nai_plugin/tipper/jquery.fs.tipper.min.js',$autoecho);
				break;
			case 'onoff':
				include_css('assets/nai_plugin/onoff/jquery.onoff.css',$autoecho);
				include_js('assets/nai_plugin/onoff/jquery.onoff.js',$autoecho);
				break;
			case 'maskedinput':
				include_js('assets/nai_plugin/maskedinput/jquery.maskedinput.min.js');
				break;
			case 'naiGrid':
				include_js('assets/nai_plugin/naiGrid/naiGrid.js');
		}
	}
	
	
	function nai_myampusers_getuser($user_xname){
		$__cache = new Cache( 'nai_myampusers_getuser', func_get_args() );
		if( $__cache->exists() ) return $__cache->get();
		global $nai_db;
		$user_x = $nai_db->querytoarray("SELECT * FROM ampusers WHERE username = '$user_xname';");
		return $__cache->put( $user_x[0] );
	}
	
	

	function nai_myampusers_getusergroups($user_x_name){
		$__cache = new Cache( 'nai_myampusers_getusergroups', func_get_args() );
		if( $__cache->exists() ) return $__cache->get();
		
		global $nai_db;
		$ret = array();
		$user_x = nai_myampusers_getuser($user_x_name);
		$user_x_id = $user_x['id'];
		$groups = $nai_db->querytoarray("SELECT group_id FROM group_members WHERE user_id = '$user_x_id';");
		foreach($groups as $val){
			$t = $nai_db->querytoarray("SELECT * FROM `group` WHERE id = '$val[group_id]';");
			$ret[] = $t[0];
		}
		return $__cache->put( $ret );
	}
	

	function nai_myampusers_is_admin($user_xname){ // child of nai_myampusers_getuser
		global $nai_db;
		if( $user_xname == 'ERROR' ) return false;
		$user_x = nai_myampusers_getuser($user_xname);
		$user_x_id = $user_x['id'];
		if(!$user_x_id) return true;
		return $user_x_id=='1'?true:false;
	}
	function nai_myampusers_is_admin_byid($user_x_id){
		return $user_x_id=='1'?true:false;
	}
	
	
	
	function nai_is_module_installed($module_name){
		$__cache = new Cache( 'nai_is_module_installed', func_get_args() );
		if( $__cache->exists() ) return $__cache->get();
		
		global $nai_db;
		$module = $nai_db->querytoarray("SELECT `modulename` FROM `modules` WHERE `modulename` = '$module_name' AND `enabled` = 1;");
		return $__cache->put( $module[0]['modulename']!=''?true:false );
	}
	
	
	function nai_is_module_disabled($module_name){
		$__cache = new Cache( 'nai_is_module_disabled', func_get_args() );
		if( $__cache->exists() ) return $__cache->get();
		
		global $nai_db;
		$module = $nai_db->querytoarray("SELECT `enabled` FROM `modules` WHERE `modulename` = '$module_name';");
		return $__cache->put( $module[0]['enabled']=='1'? false: true );
	}
	
	function nai_module_access_options($module_name){
		$username = $_SESSION['AMP_user']->username;
		$args = func_get_args();
		$args[] = $username;
		$__cache = new Cache( 'nai_module_access_options', $args);
		if( $__cache->exists() ) return $__cache->get();

		global $nai_db;
		if( ! nai_is_module_installed('groups') ||  nai_myampusers_is_admin($username) ) return $__cache->put(true);
		//$display = $display=='index'?'dashboard':$display;
		//$module = nai_mymodulesadmin_getmodule($display);
		$user_xgroups = nai_myampusers_getusergroups($username);
		$permissions_to_this_page = array();

		foreach($user_xgroups as $group){
			$per_ = $nai_db->querytoarray("SELECT * FROM `permission` WHERE group_id = '$group[id]' AND `name` = '$module_name' AND web_resource = TRUE;");
			foreach($per_ as $perr){
				if( $perr['in_permission'] == '' ){
					return $__cache->put(true);
				}
				else{
					if( ! in_array( $perr['in_permission'] , $permissions_to_this_page))
						$permissions_to_this_page[] = $perr['in_permission'];
				}
			}
		}
		return $__cache->put($permissions_to_this_page);
	}
	function nai_check_this_user_can_access_to_this_module($user_xname,$display,$fordeveloper=false){
		$__cache = new Cache( 'nai_check_this_user_can_access_to_this_module', func_get_args() );
		if( $__cache->exists() ) return $__cache->get();
		
		global $nai_db;//,$module;
		if( ! nai_is_module_installed('groups') ) return $__cache->put(true);
		$user_x = nai_myampusers_getuser($user_xname);
		
		if( $user_x['id'] == 1 ) return $__cache->put(true);
		if( $display == 'modules' && $user_x['id'] != 1 ) return $__cache->put(false); // age admin bashe k tu khate balayi true mishe, pas inja bayad false bashe
		//$display = $display=='index'?'dashboard':$display;
		$thismdl = nai_mymodulesadmin_getmodule($display);
		if( $thismdl == null ) return $__cache->put(null);
		//$module = nai_mymodulesadmin_getmodule($display);
		$user_xgroups = nai_myampusers_getusergroups($user_xname);
		$permissions_to_this_page = array();
		
		foreach($user_xgroups as $group){
			$per_ = $nai_db->querytoarray("SELECT * FROM `permission` WHERE group_id = '$group[id]' AND `name` = '$display' AND web_resource = TRUE;");
			foreach($per_ as $perr){
				if( $perr['in_permission'] == '' ){
					return $__cache->put(true);
				}
				else{
					if( ! in_array( $perr['in_permission'] , $permissions_to_this_page))
						$permissions_to_this_page[] = $perr['in_permission'];
				}
			}
		}

		if(count($permissions_to_this_page)>0){
			if($thismdl['ifaccessloadanyway'] == 'true') return $__cache->put(true);
			$ret = array();
			foreach($permissions_to_this_page as $perrr){
				$expp = explode('&',$perrr);
				$n = true;
				foreach($expp as $exppp){
					$exp = explode('=',$exppp);
					$key = $exp[0];
					$value = $exp[1];
					if( $value != getor( $_REQUEST[$key] ) ) $n = false;
				}
				if($n==true) return $__cache->put(true);
				if( $fordeveloper )
					$ret[] = $perrr;
				else
					$ret[] = "<a href=\"config.php?display=$display&$perrr\"> $perrr </a>";
			}

			
			return $__cache->put($ret);
		}
		else{
			return $__cache->put(false);
		}
	}

	function nai_can_access_to_this_option( $display, $optionName, $optionValue ){
		$__cache = new Cache( 'nai_can_access_to_this_option', func_get_args() );
		if( $__cache->exists() ) return $__cache->get();
		
		$acc = nai_module_access_options($display);
		if($acc!==true){
			foreach($acc as $ac){
				$t = explode('=',$ac);
				if( $t[0] == $optionName && $t[1] == $optionValue ){
					return $__cache->put(true);
				}
			}
			return $__cache->put(false);
		}
		return $__cache->put(true);
	}
	function nai_mymodulesadmin_getmodules_from_db($justenabled=true){
		$__cache = new Cache( 'nai_mymodulesadmin_getmodules_from_db', func_get_args() );
		if( $__cache->exists() ) return $__cache->get();
		global $nai_db;
		if($justenabled) $where = 'enabled = 1'; else $where = 'TRUE';
		$modules = $nai_db->querytoarray("SELECT * FROM modules WHERE $where;");
		return $__cache->put($modules);
		
		
	}
	function nai_mymodulesadmin_getmodules_to_array($retcat = false){
		$__cache = new Cache( 'nai_mymodulesadmin_getmodules_to_array', func_get_args() );
		if( $__cache->exists() ) return $__cache->get();
		
		$dir__ = $amp_conf['AMPWEBROOT'] . '/admin';
		$ret = array();
		$modules = nai_mymodulesadmin_getmodules_from_db();
		$i=0;
		$all_category = array();
		$all_subcategory = array();
		foreach($modules as $module){
				$module_directory = '/var/www/html' . $dir__ . '/modules/'.$module['modulename'].'/';
				$module_xml_file_address = file_get_contents( $module_directory.'/'.'module.xml');
				$xml = XMLtoArray($module_xml_file_address);
				
				$n = 0;
				foreach($xml['MODULE']['MENUITEMS'] as $menuitem => $etelaat){
					$ret[$i]['directory'] = $module_directory;
					$ret[$i]['xml']['content'] = $xml;
					$ret[$i]['xml']['directory'] = $module_xml_file_address;

					if( isset($xml['MODULE']['MENUITEMS'][$menuitem]['CATEGORY']) && strlen($xml['MODULE']['MENUITEMS'][$menuitem]['SUBCATEGORY']) > 1)
						$ret[$i]['category'] = $xml['MODULE']['MENUITEMS'][$menuitem]['CATEGORY'];
					else
						$ret[$i]['category'] = $xml['MODULE']['CATEGORY'];
						
					if( isset($xml['MODULE']['MENUITEMS'][$menuitem]['SUBCATEGORY']) && strlen($xml['MODULE']['MENUITEMS'][$menuitem]['SUBCATEGORY']) > 1)
						$ret[$i]['subcategory'] = $xml['MODULE']['MENUITEMS'][$menuitem]['SUBCATEGORY'];
					else
						$ret[$i]['subcategory'] = $xml['MODULE']['SUBCATEGORY'];

					$ret[$i]['rel'] =  getor ( $xml['MODULE']['REL'] , $xml['MODULE']['REL']);
					$ret[$i]['name'] = strtolower($menuitem);
					$ret[$i]['title'] = is_array ( $etelaat ) ? $etelaat['content'] : $etelaat ;
					$ret[$i]['href'] = 'config.php?display=' . strtolower($menuitem);
					$ret[$i]['ifaccessloadanyway'] = getor ( $xml['MODULE']['IFACCESSLOADANYWAY'] , $xml['MODULE']['IFACCESSLOADANYWAY']);
					
					$all_category[$ret[$i]['category']][$ret[$i]['subcategory']][] = $ret[$i];
					$i++;
				}
				
		}
		//print_r($all_category);
		return $__cache->put( ($retcat? $all_category: $ret) );
	}
	
	function nai_mymodulesadmin_getmodule($module_name){
		$__cache = new Cache( 'nai_mymodulesadmin_getmodule', func_get_args() );
		if( $__cache->exists() ) return $__cache->get();
		$dir__ = $amp_conf['AMPWEBROOT'] . '/admin';
		$ret = array();
		$modules = nai_mymodulesadmin_getmodules_from_db();
		foreach($modules as $module){
				$module_directory = '/var/www/html' . $dir__ . '/modules/'.$module['modulename'].'/';
				$module_xml_file_address = file_get_contents( $module_directory.'/'.'module.xml');
				$xml = XMLtoArray($module_xml_file_address);
				
				$n = 0;
				foreach($xml['MODULE']['MENUITEMS'] as $menuitem => $etelaat){
					if(strtolower($menuitem) == strtolower($module_name)){
						$ret['directory'] = $module_directory;
						$ret['xml']['content'] = $xml;
						$ret['xml']['directory'] = $module_xml_file_address;
						$ret['category'] = getor ( $xml['MODULE']['CATEGORY'] , $xml['MODULE']['CATEGORY']);
						$ret['subcategory'] = getor ( $xml['MODULE']['SUBCATEGORY'] , $xml['MODULE']['SUBCATEGORY']);
						$ret['rel'] =  getor ( $xml['MODULE']['REL'] , $xml['MODULE']['REL']);
						$ret['name'] = strtolower($menuitem);
						$ret['rawname'] = strtolower($xml['MODULE']['RAWNAME']);
						$ret['title'] = is_array ( $etelaat ) ? $etelaat['content'] : $etelaat ;
						$ret['href'] = 'config.php?display=' . strtolower($menuitem);
						$ret['ifaccessloadanyway'] = getor ( $xml['MODULE']['IFACCESSLOADANYWAY'] , $xml['MODULE']['IFACCESSLOADANYWAY']);
						return $__cache->put($ret);
					}
				}
		}
		return $__cache->put($null);
	}
	
	function nai_add_alert($text, $userClass = ''){
		global $alert_in_page;
		$text = str_replace('"','',$text);
		$text = str_replace("'",'',$text);
		$text = str_replace("\n",'<br>',$text);




		$alert_in_page.= tag('tr'," class='$userClass' ",
									tag('td','class=\'closebtn\'', tag('span','class=\'icon icon-times s18\'') ) .
									tag('td','class=\'text\'',$text)
			);
			
		//$alert_in_page.= $text.'\n';
	}
	function nai_get_alerts(){
		global $alert_in_page;
		return $alert_in_page;
	}
	
	
	function nai_basemodules_includes_panel(){
		global $username;
		if( !ncl() ) return false;
		$nai_modules = nai_mymodulesadmin_getmodules_from_db();
		
		foreach( $nai_modules as $nai_module ) {
			$nai_module_ = nai_mymodulesadmin_getmodule($nai_module['modulename']);
			if( nai_check_this_user_can_access_to_this_module($username,$nai_module['modulename']) === false )
				continue;
			
			$nai_basejs = $nai_module_['xml']['content']['MODULE']['BASEPANEL']['JS'];
			if( is_array($nai_basejs) )
				foreach ( $nai_basejs as $nai_jsfile )
					echo tag('script','src="modules/'.$nai_module['modulename'].'/'.$nai_jsfile.'"','');
			elseif( $nai_basejs )
				echo tag('script','src="modules/'.$nai_module['modulename'].'/'.$nai_basejs.'"','');
				
			$nai_basecss = $nai_module_['xml']['content']['MODULE']['BASEPANEL']['CSS'];
			if( is_array($nai_basecss) )
				foreach ( $nai_basecss as $nai_cssfile )
					echo tag('link','href="modules/'.$nai_module['modulename'].'/'.$nai_cssfile.'" rel="stylesheet" type="text/css"','');
			elseif( $nai_basecss )
				echo tag('link','href="modules/'.$nai_module['modulename'].'/'.$nai_basecss.'" rel="stylesheet" type="text/css"','');

				
			$nai_basephp = $nai_module_['xml']['content']['MODULE']['BASEPANEL']['PHP'];
			if( is_array($nai_basephp) )
				foreach ( $nai_basephp as $nai_phpfile )
					include 'modules/'.$nai_module['modulename'].'/'.$nai_phpfile;
			elseif( $nai_basephp )
				include 'modules/'.$nai_module['modulename'].'/'.$nai_basephp;
		}
	}
	
	function nai_basemodules_includes_header(){
		global $username;
		if( !ncl() ) return false;
		$nai_modules = nai_mymodulesadmin_getmodules_from_db();
		
		foreach( $nai_modules as $nai_module ) {
			$nai_module_ = nai_mymodulesadmin_getmodule($nai_module['modulename']);
			if( nai_check_this_user_can_access_to_this_module($username,$nai_module['modulename']) === false )
				continue;
			
			$nai_basejs = $nai_module_['xml']['content']['MODULE']['BASEHEADER']['JS'];
			if( is_array($nai_basejs) )
				foreach ( $nai_basejs as $nai_jsfile )
					echo tag('script','src="modules/'.$nai_module['modulename'].'/'.$nai_jsfile.'"','');
			elseif( $nai_basejs )
				echo tag('script','src="modules/'.$nai_module['modulename'].'/'.$nai_basejs.'"','');
				
			$nai_basecss = $nai_module_['xml']['content']['MODULE']['BASEHEADER']['CSS'];
			if( is_array($nai_basecss) )
				foreach ( $nai_basecss as $nai_cssfile )
					echo tag('link','href="modules/'.$nai_module['modulename'].'/'.$nai_cssfile.'" rel="stylesheet" type="text/css"','');
			elseif( $nai_basecss )
				echo tag('link','href="modules/'.$nai_module['modulename'].'/'.$nai_basecss.'" rel="stylesheet" type="text/css"','');

				
			$nai_basephp = $nai_module_['xml']['content']['MODULE']['BASEHEADER']['PHP'];
			if( is_array($nai_basephp) )
				foreach ( $nai_basephp as $nai_phpfile )
					include 'modules/'.$nai_module['modulename'].'/'.$nai_phpfile;
			elseif( $nai_basephp )
				include 'modules/'.$nai_module['modulename'].'/'.$nai_basephp;
		}
	}
	
	
	function nai_log($x){
		$content = null;
		$fAddress = 'nai_log.txt';
		$content = nai_read_file($fAddress);
		nai_write_file($fAddress, date('Y-m-d G:i:s').': '.$x."\n".$content);
	}

	function nai_server_id(){
		return md5( nai_mac_address() );
	}
	

	function nai_check_lisance(){
		ncl();
	}
	function ncl(){
		$__cache = new Cache( 'ncl', func_get_args() );
		if( $__cache->exists() ) return $__cache->get();

		$file = 'nailic';
		if( !file_exists($file) ){
			return $__cache->put(false);
			//nai_write_file($file, nai_server_id());
			//return true;
		}
		else{
			$isorg = nai_read_file($file)==str2hex(nai_server_id($file))?true:false;
			return $__cache->put($isorg);
		}

	}
	

	
	
	function nai_write_file($file_name, $file_content=null){
		//$ret = true;
		$fileLink = fopen( $file_name , 'w');
		if( $file_content != null ) $ret = fwrite($fileLink, $file_content);
		fclose( $fileLink );
		return $ret;
	}
	function nai_read_file($file_name){
		if( file_exists($file_name) )
			return file_get_contents ( $file_name );
		else
			return false;
	}
	
	function nai_mac_address() {
		exec('netstat -ie', $result);
		if(is_array($result)) {
			$iface = array();
			foreach($result as $key => $line) {
				if($key > 0) {
					$tmp = str_replace(" ", "", substr($line, 0, 10));
					if($tmp <> "") {
						$macpos = strpos($line, "HWaddr");
						if($macpos !== false) {
							$iface[] = array('iface' => $tmp, 'mac' => strtolower(substr($line, $macpos+7, 17)));
						}
					}
				}
			}
			return $iface[0]['mac'];
		}
		else {
			return "notfound";
		}
	}


	function nai_action_in_server( $whattodo ){
		switch($whattodo){
			case 'macpl':
				$check = shell_exec("/usr/bin/sudo /usr/sbin/pbxcmd xmlconfig $server_address -f");
				$check_text = print_r($check,true)!=''?print_r($check,true):'پاسخی از سرور دریافت نشد!';
				return('پیکربندی تلفن ها : '.$check_text );
				break;
			case 'shutdownserver':
				$check = shell_exec("/usr/bin/sudo /usr/sbin/pbxcmd shutdown $server_address -f");
				$check_text = print_r($check,true)!=''?print_r($check,true):'پاسخی از سرور دریافت نشد!';
				return($check_text);
				break;
			case 'restartserver':
				$check = shell_exec("/usr/bin/sudo /usr/sbin/pbxcmd restart $server_address -f");
				$check_text = print_r($check,true)!=''?print_r($check,true):'پاسخی از سرور دریافت نشد!';
				return($check_text );
				break;
			case 'reloadcache':
				global $__cache_global;
				$__cache_global->publicReload();
				$check_text ='حافظه‌نهان با موفقیت به‌روزرسانی شد';
				return($check_text );
				break;
			default:
				return 'درخواست اشتباه!';
		
		}
	}

	
?>